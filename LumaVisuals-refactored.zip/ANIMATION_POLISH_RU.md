# Animation & UI Polish Pass — 2026-09-08

База: сохранённый LumaVisuals-0.1.5-InputFix.zip. Это продолжение существующего Alpha-проекта, не новая UI/Animation architecture. Версия мода и форматы настроек сохранены.

## Changed / Improved
- Motion.java: общий response/exit response, конечные bounded delta, ease-out для stagger, fade/scale/slide коэффициенты. Motion.Values расширяет существующую систему каналами с переиспользованием состояния вместо покадрового boxing Double.
- Menu.java: плавное открытие/закрытие с fade + 0.97→1 scale и смещением до 12 logical px. Закрытие меняет цель текущей анимации, не сбрасывает прогресс.
- Вкладки: исходящий контент сначала затухает и сдвигается; затем входит выбранная вкладка. Быстрые запросы сохраняют последний target. UI не рендерит одновременно две полные страницы и не создаёт offscreen framebuffer.
- Stagger основных карточек оформления/фона: шаг 22 ms, задержка ограничена 88 ms, cubic ease-out 220 ms. При закрытии stagger не перезапускается. Остальные карточки участвуют в общей смене вкладки.
- Наведение, переключатели, иконки и sliders используют те же Motion channels; кэшируются определения Option и результаты фильтрации. Убраны повторные списки utilities/options и динамические animation-key конкатенации.
- HudSettingsPanel.java: общий fade/scale/slide, плавные toggle/hover, подсветка слайдеров, существующий SmoothScroll. Scroll bounds вычисляются до отрисовки, чтобы resize не расходился с hit map.
- LumaHudScreen.java: экран остаётся до завершения exit animation; input блокируется уже при запросе закрытия. Передача frame delta в существующую панель.
- HudLayout.java: плавные появление/исчезновение и изменение ширины карточек, сворачивание свободного места. Фиксированные primitive arrays для состояния; убраны временные списки/stream обработки строк HUD и копирование списка icons при каждом чтении.
- HUD equipment: фон/текст затухают; native item icons масштабируются вместе с карточкой без вмешательства в GL shader color. Последние шесть icon keys удерживаются на время выхода; очищаются при смене мира. Альфа реальных Minecraft item icons отдельно не переопределяется.
- HUD editor: анимации геометрии не конкурируют с drag — во время редактирования используются стабильные реальные bounds. При смене мира/размеров сбрасываются устаревшие drag states.
- MinecraftCanvas.java: убрано покадровое округление origin/baseline текста, мешавшее субпиксельным slide/scale. Сохранены существующие atlas, linear sampling и rendering pipeline. Эффект в настоящем GL требует проверки на устройстве.

## Fixed / input safety
Сохранены шесть InputFix-регрессий. Исходящие и ещё почти невидимые карточки не принимают активацию; клики пересчитываются через тот же content slide, что используется в render. Закрытие останавливает drag. Resize отменяет старые координаты drag. Reduced motion / motion OFF дают мгновенные состояния, в том числе при нулевом delta.

## Verified — фактически выполнено на итоговых восстановленных файлах
Рабочая среда сбросилась до первой упаковки. Исходники восстановлены поверх сохранённого InputFix, и весь итоговый прогон выполнен заново.

- Core + все preview/src: PASS, компилятор JDK 25 с --release 21. Это не полная Fabric-компиляция и не запуск на JDK 21.
- AnimationChecks: 39 436 assertions на реальном shared Java core. Синтетические 30/60/120 Hz для damping; переходы/прерывания; input/drag/closed-state; размеры 640×360, 1280×720, 1920×1080; три HUD style; отсутствие overlap default HUD и соответствие item bounds; ограниченный кэш animation channels.
- MenuChecks: прежние 532 assertions, 24 window/scale combinations + 6 InputFix cases — PASS.
- Остальные существующие наборы RenderBudgetChecks, UtilityChecks (283), ToolSafetyChecks (5013), NewFeatureChecks (1909), RevisionChecks (74), CustomSkinChecks (211) — PASS.
- UtilityChecks: исходные проверки прокрутки сохранены; после запроса вкладки добавлено ожидание новых двухфазных переходов вместо предположения, что они закончились за один кадр.
- AnimationChecks запускается из существующего MenuChecks, поэтому новый workflow не требуется.
- validate_mobilefix.py: 81 693 static/math assertions — PASS.
- recording_check.py: 5 248 assertions с recording doubles — PASS. Это не подтверждение настоящих Minecraft API signatures или OpenGL.
- Восемь PNG состояний просмотрены по отдельности: menu opening, hover, outgoing/incoming tab, closing, HUD panel hover, small HUD panel, HUD card exit. Проверены видимые отступы, клиппинг и отсутствие непредусмотренных наложений. Это software previews, не Minecraft screenshots.
- Изменения build.yml: НЕТ; оба исходных файла workflow сохранены byte-for-byte.

## Remaining / границы
- Fabric/Gradle build: NOT RUN; Gradle отсутствует в рабочей среде. JAR не создавался.
- IN-GAME VERIFICATION: NOT RUN. Игру не запускали по запросу пользователя.
- Android/Zalith/MobileGlues, GL text sharpness, shader compile, native item rendering и реальные FPS/allocations не измерялись.
- Проверка переиспользования animation state и удаления временных коллекций не означает zero-allocation всего существующего renderer: hit regions, подписи и Canvas adapter по-прежнему имеют собственные затраты.

## Проверка на устройстве после CI-сборки
1. Opening/closing и быстрый повторный ввод, Escape во время drag.
2. Быстрые клики вкладок, обратный переход на исходную вкладку, Enter/Tab при fading content.
3. Sliders, scroll, смена разрешения и HUD settings → Назад → повторное открытие.
4. HUD editor в чате, групповое перемещение, toggles visible/enabled, смена экипировки/мира.
5. Motion OFF / reduced, несколько GUI scales, сохранение настроек после перезапуска.
6. Проверить native glyph sharpness и item icons именно на MobileGlues.

## Файлы
Полные актуальные исходники находятся по прежним путям. Единственный новый Java-класс — preview/src/dev/luma/preview/AnimationChecks.java (тесты, не runtime architecture).
Diff относительно InputFix: verification/animation-polish/changes.diff.
Лог: verification/animation-polish/regression.log.
Офлайн-превью: preview/animation-polish/ (PROVENANCE.txt описывает происхождение).
SHA256SUMS.txt обновлён для всего проекта.

## Важно для существующего CI
Workflow по-прежнему выбирает старый LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip раньше распакованных исходников. Для сборки новой версии заменить распакованные исходники и убрать старый приоритетный ZIP. Простое добавление нового ZIP с другим именем не означает, что workflow соберёт именно его. build.yml не менялся и не дублировался.

STATIC/OFFLINE CHECKS PASSED — READY FOR IN-GAME TEST after Fabric build.
