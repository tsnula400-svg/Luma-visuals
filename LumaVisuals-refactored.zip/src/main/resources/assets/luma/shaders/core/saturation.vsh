#version 150
#if defined(GL_ES) || defined(MG_MOBILEGLUES)
precision highp float;
precision highp int;
#endif
in vec3 Position;
out vec2 uv;
void main(){gl_Position=vec4(Position,1.0);uv=Position.xy*0.5+0.5;}
