package dev.luma.client;
import dev.luma.core.HudSettingsPanel;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
public final class LumaHudScreen extends Screen {
    private final Screen parent;
    private long lastFrame=System.nanoTime();
    private final HudSettingsPanel panel=new HudSettingsPanel(LumaClient.settings);
    public LumaHudScreen(Screen parent){super(Text.literal("Luma HUD"));this.parent=parent;}
    private double ratio(){return client.getWindow().getScaleFactor();}
    @Override public boolean shouldPause(){return false;}
    @Override public void renderBackground(DrawContext c,int x,int y,float delta){}
    @Override public void render(DrawContext c,int x,int y,float delta){
        long now=System.nanoTime();double elapsed=(now-lastFrame)/1_000_000_000.0;lastFrame=now;
        try(MinecraftCanvas canvas=new MinecraftCanvas(c,textRenderer)){
            canvas.push(0,0,1/ratio(),1);try{panel.render(canvas,client.getWindow().getFramebufferWidth(),client.getWindow().getFramebufferHeight(),x*ratio(),y*ratio(),elapsed);}finally{canvas.pop();}
        }
        if(panel.closed())client.setScreen(parent);
    }
    @Override public boolean mouseClicked(double x,double y,int b){return panel.click(x*ratio(),y*ratio(),b);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){if(b==0){panel.move(x*ratio(),y*ratio());return true;}return false;}
    @Override public boolean mouseReleased(double x,double y,int b){panel.release();if(panel.takeChanged())LumaClient.save();return true;}
    @Override public boolean mouseScrolled(double x,double y,double hx,double vy){panel.scroll(vy);return true;}
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==256||LumaClient.menuKey.matchesKey(key,scan)){close();return true;}if(key==267||key==266){panel.scroll(key==267?-5:5);return true;}return super.keyPressed(key,scan,mods);}
    @Override public void close(){panel.close();}
    @Override public void removed(){LumaClient.save();panel.release();}
}
