package dev.luma.client.mixin;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import dev.luma.client.LumaClient;
import dev.luma.core.SwingTransform;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.*;
/** Yarn 1.21.4+build.8 render arguments only. No entity/combat/network modifications. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
 @Shadow private void applyEquipOffset(MatrixStack matrices,Arm arm,float progress){throw new AssertionError("Mixin shadow");}
 @Unique private final Quaternionf lume$rotation=new Quaternionf();
 @Unique private final SwingTransform lume$swing=new SwingTransform();
 @Unique private boolean lume$renderScope;
 @WrapMethod(method="renderFirstPersonItem")
 private void lume$viewModel(AbstractClientPlayerEntity player,float tickDelta,float pitch,Hand hand,float swingProgress,ItemStack item,float equipProgress,MatrixStack matrices,VertexConsumerProvider consumers,int light,Operation<Void> original){
  var s=LumaClient.settings;
  // Keep special map/crossbow/empty-hand paths vanilla, and only the hand that actually holds the item in use
  // (shield/food/bow). The opposite hand keeps the selected Swing Animation while blocking. Render only.
  boolean lume$activeHand=player.isUsingItem()&&player.getActiveHand()==hand;
  if(s==null||!s.viewModel.enabled||item.isEmpty()||item.contains(DataComponentTypes.MAP_ID)||item.isOf(Items.CROSSBOW)||lume$activeHand){original.call(player,tickDelta,pitch,hand,swingProgress,item,equipProgress,matrices,consumers,light);return;}
  var vm=s.viewModel;var pose=hand==Hand.MAIN_HAND?vm.main:vm.off;boolean previous=lume$renderScope;lume$renderScope=true;matrices.push();
  try{matrices.translate(pose.horizontal,pose.vertical,-pose.distance);lume$rotate(matrices,pose.pitch,pose.yaw,pose.tilt);matrices.scale((float)pose.scale,(float)pose.scale,(float)pose.scale);double progress=s.viewModelPreview&&s.previewSwing?s.previewProgress:swingProgress;original.call(player,tickDelta,pitch,hand,(float)vm.progress(progress),item,(float)vm.equip(equipProgress),matrices,consumers,light);}
  finally{matrices.pop();lume$renderScope=previous;}
 }
 @WrapMethod(method="swingArm")
 private void lume$swing(float progress,float equip,MatrixStack matrices,int armX,Arm arm,Operation<Void> original){
  var s=LumaClient.settings;if(s==null||!lume$renderScope||s.viewModel.swingStyle<3||s.viewModel.swingStyle==6){original.call(progress,equip,matrices,armX,arm);return;}
  applyEquipOffset(matrices,arm,equip);lume$swing.evaluate(s.viewModel,progress,armX);matrices.translate(lume$swing.x,lume$swing.y,lume$swing.z);lume$rotate(matrices,lume$swing.pitch,lume$swing.yaw,lume$swing.roll);float scale=(float)lume$swing.scale;matrices.scale(scale,scale,scale);
 }
 @Unique private void lume$rotate(MatrixStack m,double x,double y,double z){double r=Math.PI/180;m.multiply(lume$rotation.rotationXYZ((float)(x*r),(float)(y*r),(float)(z*r)));}
}
