package dev.luma.client.mixin;
import dev.luma.client.DropSafety;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ClientPlayerEntity.class)
public abstract class DropPlayerMixin {
    @Inject(method="dropSelectedItem",at=@At("HEAD"),cancellable=true) private void luma$protect(boolean entire,CallbackInfoReturnable<Boolean> cir){
        ClientPlayerEntity p=(ClientPlayerEntity)(Object)this;
        if(!DropSafety.allow(p.getInventory(),p.getInventory().selectedSlot,p.getMainHandStack(),entire))cir.setReturnValue(false);
    }
}
