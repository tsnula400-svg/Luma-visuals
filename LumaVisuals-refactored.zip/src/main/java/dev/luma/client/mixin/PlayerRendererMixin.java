package dev.luma.client.mixin;

import dev.luma.client.skin.CustomSkinManager;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerRendererMixin {
    // 1.21.4 renders snapshots, not AbstractClientPlayerEntity parameters.
    // OFF does not cancel or change the vanilla return value.
    @Inject(method = "getTexture(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;",
            at = @At("RETURN"), cancellable = true)
    private void luma$customSkinTexture(PlayerEntityRenderState state, CallbackInfoReturnable<Identifier> cir) {
        if (CustomSkinManager.isEnabledFor(state)) {
            cir.setReturnValue(CustomSkinManager.SKIN_TEXTURE);
        }
    }

    // Covers left/right hands and maps, without replacing the held-item renderer.
    // Only a local argument changes: no cached vanilla texture needs restoration.
    @ModifyVariable(method = "renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Identifier;Lnet/minecraft/client/model/ModelPart;Z)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private Identifier luma$customArmTexture(Identifier original) {
        return CustomSkinManager.isFirstPersonEnabled() ? CustomSkinManager.SKIN_TEXTURE : original;
    }
}
