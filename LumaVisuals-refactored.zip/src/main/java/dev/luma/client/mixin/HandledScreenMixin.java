package dev.luma.client.mixin;

import dev.luma.client.LumaClient;
import dev.luma.core.DragTransfer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

/** Shift + held LMB. One quick-move per source slot; no queued clicks after release. */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin extends Screen {
    @Shadow @Final protected ScreenHandler handler;
    @Shadow private Slot getSlotAt(double x,double y){throw new AssertionError();}
    @Shadow protected abstract void onMouseClick(Slot slot,int slotId,int button,SlotActionType actionType);
    @Unique private final DragTransfer luma$gesture=new DragTransfer();
    @Unique private boolean luma$ownsLeft;
    protected HandledScreenMixin(Text title){super(title);}

    @Unique private boolean luma$allowed(){
        return client!=null&&client.player!=null&&client.interactionManager!=null
            &&LumaClient.settings!=null&&LumaClient.settings.itemScroller
            &&client.currentScreen==(Object)this&&client.player.currentScreenHandler==handler
            &&!(client.currentScreen instanceof CreativeInventoryScreen)
            &&!client.player.isSpectator()&&!client.options.getTouchscreen().getValue()
            &&Screen.hasShiftDown()&&handler.getCursorStack().isEmpty();
    }
    @Unique private boolean luma$ordinary(Slot slot){
        // Output, ghost, armour and special modded slots have different semantics: leave them vanilla.
        return slot!=null&&slot.getClass()==Slot.class&&slot.isEnabled();
    }
    @Unique private void luma$transfer(double x,double y){
        Slot slot=getSlotAt(x,y);
        if(luma$ordinary(slot)&&slot.hasStack()&&slot.canTakeItems(client.player)
            &&luma$gesture.visit(slot.id,slot.inventory)){
            onMouseClick(slot,slot.id,0,SlotActionType.QUICK_MOVE);
        }
    }
    @Inject(method="mouseClicked",at=@At("HEAD"),cancellable=true)
    private void luma$start(double x,double y,int button,CallbackInfoReturnable<Boolean> cir){
        if(button!=0){if(luma$ownsLeft){luma$gesture.end();cir.setReturnValue(true);}return;}
        luma$gesture.end();luma$ownsLeft=false;
        if(!luma$allowed())return;
        Slot slot=getSlotAt(x,y);if(!luma$ordinary(slot))return;
        luma$gesture.begin(slot.inventory);luma$ownsLeft=true;
        luma$transfer(x,y);cir.setReturnValue(true);
    }
    @Inject(method="mouseDragged",at=@At("HEAD"),cancellable=true)
    private void luma$sweep(double x,double y,int button,double dx,double dy,CallbackInfoReturnable<Boolean> cir){
        if(button!=0||!luma$ownsLeft)return;
        if(luma$allowed()&&luma$gesture.active())luma$transfer(x,y);else luma$gesture.end();
        cir.setReturnValue(true);
    }
    @Inject(method="mouseReleased",at=@At("HEAD"),cancellable=true)
    private void luma$release(double x,double y,int button,CallbackInfoReturnable<Boolean> cir){
        if(button==0){boolean owned=luma$ownsLeft;luma$gesture.end();luma$ownsLeft=false;if(owned)cir.setReturnValue(true);}
    }
    @Override public boolean keyReleased(int key,int scan,int mods){
        if(key==340||key==344)luma$gesture.end();
        return super.keyReleased(key,scan,mods);
    }
    @Inject(method="removed",at=@At("HEAD"))
    private void luma$removed(CallbackInfo ci){luma$gesture.end();luma$ownsLeft=false;}
}
