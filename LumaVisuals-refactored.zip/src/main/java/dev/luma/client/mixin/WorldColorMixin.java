package dev.luma.client.mixin;
import dev.luma.client.WorldColor;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(GameRenderer.class)
public abstract class WorldColorMixin {
    @Inject(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/GameRenderer;renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V",shift=At.Shift.AFTER))
    private void luma$colour(RenderTickCounter counter,boolean tick,CallbackInfo ci){WorldColor.apply();}
}
