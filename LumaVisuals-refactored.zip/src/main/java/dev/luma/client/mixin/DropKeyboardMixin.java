package dev.luma.client.mixin;
import dev.luma.client.DropSafety;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Keyboard.class)
public abstract class DropKeyboardMixin {
    @Inject(method="onKey",at=@At("HEAD")) private void luma$fresh(long window,int key,int scan,int action,int mods,CallbackInfo ci){
        if(window==MinecraftClient.getInstance().getWindow().getHandle())DropSafety.key(key,scan,action);
    }
}
