package dev.luma.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.luma.core.RatioPresets;
import dev.luma.core.Settings;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/**
 * Mobile-safe image resolution. The complete scene uses vanilla's framebuffer,
 * depth buffer and native window dimensions. Only its finished COLOR is sampled
 * down/up before the HUD. This is NOT reduced-cost low-resolution world rendering.
 * No framebuffer/window getter substitutions, depth resampling or GL projection hacks.
 */
public final class WorldResolution {
    private WorldResolution() {}
    private static final class ImageTarget extends Framebuffer { ImageTarget(){super(false);} }
    private static ImageTarget buffer;
    private static boolean inWorld;
    private static float multiplier=1;
    private static final int[] VIEWPORT=new int[4], SCISSOR=new int[4];
    private static final boolean ALTERNATE=FabricLoader.getInstance().isModLoaded("iris")
        ||FabricLoader.getInstance().isModLoaded("vulkanmod")
        ||FabricLoader.getInstance().isModLoaded("optifabric")
        ||FabricLoader.getInstance().isModLoaded("canvas")
        ||FabricLoader.getInstance().isModLoaded("resolutioncontrol")
        ||FabricLoader.getInstance().isModLoaded("resolutioncontrolplus");

    public static float projectionMultiplier(){
        return inWorld&&RenderSystem.isOnRenderThread()?multiplier:1;
    }

    public static void begin(){
        RenderSystem.assertOnRenderThread();
        inWorld=false;multiplier=1;
        var client=MinecraftClient.getInstance();Settings s=LumaClient.settings;
        if(s==null||!s.ratioEnabled||client.world==null){releaseBuffer();return;}
        if(ALTERNATE){releaseBuffer();s.ratioStatus="Ratio недоступен с альтернативным рендером";return;}
        int w=client.getWindow().getFramebufferWidth(),h=client.getWindow().getFramebufferHeight();
        if(w<1||h<1)return;
        double nativeAspect=w/(double)h;
        multiplier=(float)RatioPresets.projectionMultiplier(nativeAspect,RatioPresets.desiredAspect(s,nativeAspect));
        inWorld=true;
        if(s.ratioMode==0){
            releaseBuffer();s.ratioStatus="Пропорции "+RatioPresets.aspectName(s.aspectPreset)+" · исходная чёткость";
        }
    }

    public static void end(boolean completed){
        boolean active=inWorld;
        inWorld=false;multiplier=1;
        var client=MinecraftClient.getInstance();Settings s=LumaClient.settings;
        if(!active||!completed||s==null||!s.ratioEnabled||s.ratioMode!=1)return;
        Framebuffer main=client.getFramebuffer();
        int w=main.textureWidth,h=main.textureHeight;
        int imageW=RatioPresets.width(s.resolutionPreset),imageH=RatioPresets.height(s.resolutionPreset);
        if(w<1||h<1)return;
        // Matching sample size is an exact no-op; never blit a texture onto itself.
        if(w==imageW&&h==imageH){releaseBuffer();s.ratioStatus="Картинка как экран · HUD без изменений";return;}
        int read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int draw=GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GL11.glGetIntegerv(GL11.GL_VIEWPORT,VIEWPORT);
        boolean scissor=GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX,SCISSOR);
        try{
            RenderSystem.disableScissor();
            if(buffer==null||buffer.textureWidth!=imageW||buffer.textureHeight!=imageH){
                releaseBuffer();
                int maximum=GL11.glGetInteger(GL11.GL_MAX_TEXTURE_SIZE);
                if(imageW>maximum||imageH>maximum)throw new IllegalStateException("GPU texture size limit");
                buffer=new ImageTarget();buffer.resize(imageW,imageH);
                buffer.beginWrite(true);buffer.checkFramebufferStatus();
            }
            // ALL world layers have already used a single native projection/target.
            // Source and destination never alias. Depth/stencil remain untouched.
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,main.fbo);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,buffer.fbo);
            requireComplete();
            GL30.glBlitFramebuffer(0,0,w,h,0,0,imageW,imageH,GL11.GL_COLOR_BUFFER_BIT,GL11.GL_LINEAR);
            if(GL11.glGetError()!=GL11.GL_NO_ERROR)throw new IllegalStateException("Image downsample failed");
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,buffer.fbo);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,main.fbo);
            GL30.glBlitFramebuffer(0,0,imageW,imageH,0,0,w,h,GL11.GL_COLOR_BUFFER_BIT,GL11.GL_LINEAR);
            if(GL11.glGetError()!=GL11.GL_NO_ERROR)throw new IllegalStateException("Image upscale failed");
            s.ratioStatus="Картинка "+imageW+"×"+imageH+" · "+RatioPresets.aspectName(s.aspectPreset)+" · без ускорения FPS";
        }catch(RuntimeException ex){
            s.ratioEnabled=false;s.ratioStatus="Ratio выключен: ошибка обработки картинки";
            LumaClient.LOG.warn("Luma image resolution disabled; native world rendering retained",ex);LumaClient.save();
            releaseBuffer();
        }finally{
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,draw);
            RenderSystem.viewport(VIEWPORT[0],VIEWPORT[1],VIEWPORT[2],VIEWPORT[3]);
            if(scissor)RenderSystem.enableScissor(SCISSOR[0],SCISSOR[1],SCISSOR[2],SCISSOR[3]);
            else RenderSystem.disableScissor();
        }
    }

    private static void requireComplete(){
        if(GL30.glCheckFramebufferStatus(GL30.GL_READ_FRAMEBUFFER)!=GL30.GL_FRAMEBUFFER_COMPLETE
            ||GL30.glCheckFramebufferStatus(GL30.GL_DRAW_FRAMEBUFFER)!=GL30.GL_FRAMEBUFFER_COMPLETE)
            throw new IllegalStateException("Incomplete image framebuffer");
    }
    private static void releaseBuffer(){
        if(buffer==null)return;
        ImageTarget old=buffer;buffer=null;
        int read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int draw=GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),id=old.fbo;
        try{old.delete();}finally{
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read==id?0:read);
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,draw==id?0:draw);
        }
    }
    public static void release(){RenderSystem.assertOnRenderThread();inWorld=false;multiplier=1;releaseBuffer();}
}
