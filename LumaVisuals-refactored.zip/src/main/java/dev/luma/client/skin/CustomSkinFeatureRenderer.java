package dev.luma.client.skin;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;

/** Existing 1.21.4 feature renderer, with refined geometry and body-local energy layers. */
public final class CustomSkinFeatureRenderer extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    private final ModelPart hood, ribs, cloak, cloakLeft, cloakRight, katana, eyes, bladeStreak, bladeGlow;
    private final ModelPart sleeveRight, sleeveLeft, shoulderRight, shoulderLeft, legRight, legLeft;
    private final ModelPart glint, sparks, leftIris, rightEye, rightIris;
    private final ModelPart[] gripParts = new ModelPart[4];
    private final ModelPart[] sparkParts = new ModelPart[5];

    public CustomSkinFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context, ModelPart root) {
        super(context);
        hood = root.getChild("hood");
        ribs = root.getChild("ribs");
        cloak = root.getChild("cloak");
        cloakLeft = cloak.getChild("cloak_left");
        cloakRight = cloak.getChild("cloak_right");
        katana = root.getChild("katana");
        eyes = root.getChild("eyes");
        leftIris = eyes.getChild("left_iris");
        rightEye = root.getChild("right_eye");
        rightIris = rightEye.getChild("right_iris");
        bladeStreak = root.getChild("blade_streak");
        bladeGlow = root.getChild("blade_glow");
        glint = bladeStreak.getChild("streak_grip").getChild("glint");
        sleeveRight = root.getChild("sleeve_right");
        sleeveLeft = root.getChild("sleeve_left");
        shoulderRight = sleeveRight.getChild("shoulder_right");
        shoulderLeft = sleeveLeft.getChild("shoulder_left");
        legRight = root.getChild("leg_right");
        legLeft = root.getChild("leg_left");
        sparks = root.getChild("sparks");
        ModelPart sparkGrip = sparks.getChild("sparks_grip");
        gripParts[0] = katana.getChild("katana_grip");
        gripParts[1] = bladeGlow.getChild("blade_energy");
        gripParts[2] = bladeStreak.getChild("streak_grip");
        gripParts[3] = sparkGrip;
        for (int i = 0; i < sparkParts.length; i++) sparkParts[i] = sparkGrip.getChild("spark_" + i);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider consumers, int light,
                       PlayerEntityRenderState state, float headYaw, float headPitch) {
        // Same local-player / spectator / invisible / OFF gates as the working scaffold.
        if (!CustomSkinManager.isEnabledFor(state) || state.invisible) return;
        PlayerEntityModel model = getContextModel();
        float time = state.age;
        float movement = Math.min(1.0f, Math.max(0.0f, state.limbAmplitudeMultiplier));
        float phase = state.limbFrequency;

        // Copy the current vanilla pose exactly once. Weapon layers follow BODY,
        // not the attacking arm; their identical baked children hold the back offset.
        hood.copyTransform(model.head);
        eyes.copyTransform(model.head);
        rightEye.copyTransform(model.head);
        ribs.copyTransform(model.body);
        cloak.copyTransform(model.body);
        sleeveRight.copyTransform(model.rightArm);
        sleeveLeft.copyTransform(model.leftArm);
        legRight.copyTransform(model.rightLeg);
        legLeft.copyTransform(model.leftLeg);
        katana.copyTransform(model.body);
        bladeGlow.copyTransform(model.body);
        bladeStreak.copyTransform(model.body);
        sparks.copyTransform(model.body);
        // No wrist/arm correction on a body-mounted weapon; reset prevents drift.
        for (ModelPart grip : gripParts) grip.resetTransform();

        // Preserve the original idle/walk frequencies, but sway the FREE waist panels
        // rather than rotating the entire mantle about the player's chest.
        cloakLeft.resetTransform();
        cloakRight.resetTransform();
        float sway = .04f * (float)Math.sin(time * .28f)
            + .08f * movement * (float)Math.sin(phase * .6f);
        float clearance = .10f + .78f * movement;
        cloakLeft.pitch = clearance + sway;
        cloakRight.pitch = clearance + sway * .85f;
        cloakLeft.roll = .03f * (float)Math.sin(time * .37f)
            + .045f * movement * (float)Math.cos(phase * .55f);
        cloakRight.roll = -.03f * (float)Math.sin(time * .42f)
            - .045f * movement * (float)Math.cos(phase * .55f);
        shoulderRight.resetTransform();
        shoulderLeft.resetTransform();
        shoulderRight.roll = .025f * (float)Math.sin(time * .28f + phase * .2f);
        shoulderLeft.roll = -.025f * (float)Math.sin(time * .28f + phase * .2f);

        VertexConsumer main = consumers.getBuffer(CustomSkinManager.MAIN_LAYER);
        draw(hood, matrices, main, light, 0xFFFFFFFF);
        draw(ribs, matrices, main, light, 0xFFFFFFFF);
        draw(cloak, matrices, main, light, 0xFFFFFFFF);
        draw(sleeveRight, matrices, main, light, 0xFFFFFFFF);
        draw(sleeveLeft, matrices, main, light, 0xFFFFFFFF);
        draw(legRight, matrices, main, light, 0xFFFFFFFF);
        draw(legLeft, matrices, main, light, 0xFFFFFFFF);
        draw(katana, matrices, main, light, 0xFFFFFFFF);

        // Full-bright additive emission works without shader-pack bloom. Animate RGB,
        // not just alpha (the vanilla Eyes layer uses additive blending).
        float pulse = pulseEnvelope(time);
        float breath = .5f - .5f * (float)Math.cos(time * (2.0 * Math.PI / 76.0));
        float leftLight = .12f + .78f * breath + .10f * pulse;
        float rightBreath = .5f - .5f * (float)Math.cos(time * (2.0 * Math.PI / 88.0) + .6);
        leftIris.resetTransform();
        rightIris.resetTransform();
        float leftSize = .175f + .015f * breath;
        leftIris.xScale = leftIris.yScale = leftIris.zScale = leftSize;
        rightIris.xScale = rightIris.yScale = rightIris.zScale = .115f;
        VertexConsumer glow = consumers.getBuffer(CustomSkinManager.GLOW_LAYER);
        draw(eyes, matrices, glow, 0xF000F0, emissionColor(leftLight));
        draw(rightEye, matrices, glow, 0xF000F0, emissionColor(.07f + .24f * rightBreath));
        draw(bladeGlow, matrices, glow, 0xF000F0, emissionColor(.22f + .68f * pulse));

        // Smooth continuous curved path, matching the generated steel silhouette.
        // The reset is invisible: sin^2 envelope has zero value and slope at both ends.
        float sweep = ((time % 64.0f) + 64.0f) % 64.0f / 64.0f;
        float travel = 3.55f + 11.65f * sweep;
        float sweepBell = (float)Math.sin(Math.PI * sweep);
        float sweepLight = sweepBell * sweepBell * (.72f + .28f * pulse);
        glint.resetTransform();
        glint.pivotY = travel;
        glint.pivotX = bladeCenter(travel);
        glint.roll = (float)Math.atan(2.7f * ((travel - 3.0f) / 13.0f) / 13.0f);
        glint.xScale = bladeWidth(travel) / .93f;
        draw(bladeStreak, matrices, glow, 0xF000F0, emissionColor(sweepLight));

        // Five bounded, back-local motes: no world particles spawned per render,
        // no queues/trails to leak after OFF, no per-frame collection allocations.
        for (int i = 0; i < sparkParts.length; i++) {
            ModelPart spark = sparkParts[i];
            spark.resetTransform();
            float a = time * .055f + i * 1.256637f;
            float y = 3.6f + i * 2.25f + .4f * (float)Math.sin(a * 1.7f);
            spark.pivotX = bladeCenter(y) + (.65f + .35f * pulse) * (float)Math.cos(a);
            spark.pivotY = y;
            spark.pivotZ = .7f * (float)Math.sin(a);
            float size = (.70f + .35f * pulse) * (.65f + .35f * (float)Math.sin(a * 1.3f));
            spark.xScale = spark.yScale = spark.zScale = size;
        }
        draw(sparks, matrices, glow, 0xF000F0, emissionColor(.12f + .78f * pulse));
    }

    private static final float PULSE_PERIOD_TICKS = 100.0f;
    private static final float PULSE_DURATION_TICKS = 80.0f;

    private static float pulseProgress(float age) {
        float phase = ((age % PULSE_PERIOD_TICKS) + PULSE_PERIOD_TICKS) % PULSE_PERIOD_TICKS;
        return Math.max(0.0f, (phase - (PULSE_PERIOD_TICKS - PULSE_DURATION_TICKS)) / PULSE_DURATION_TICKS);
    }

    static float pulseEnvelope(float age) {
        float t = pulseProgress(age);
        if (t <= 0.0f) return 0.0f;
        float bell = (float)Math.sin(Math.PI * t);
        return bell * bell;
    }

    private static int emissionColor(float level) {
        int b = Math.round(255 * Math.max(0.0f, Math.min(1.0f, level)));
        return 0xFF000000 | (b << 16) | (b << 8) | b;
    }

    private static float bladeCenter(float y) {
        float t = Math.max(0, Math.min(1, (y - 3.0f) / 13.0f));
        return -1.35f * t * t;
    }

    private static float bladeWidth(float y) {
        float t = Math.max(0, Math.min(1, (y - 3.0f) / 13.0f));
        return .93f * (1 - .22f * t) * (t > .80f ? Math.max(.025f, (1 - t) / .20f) : 1);
    }

    private static void draw(ModelPart part, MatrixStack matrices, VertexConsumer consumer, int light, int color) {
        part.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV, color);
    }
}
