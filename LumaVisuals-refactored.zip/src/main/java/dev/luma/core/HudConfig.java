package dev.luma.core;
import java.util.*;
public final class HudConfig {
    public static final String[] IDS={"nick","fps","ping","coords","speed","server","online","armor","tools"};
    public static final String[] NAMES={"Ник","FPS","Пинг","Координаты","Скорость","Сервер / мир","Онлайн","Броня","Инструменты в руках"};
    public static final String[] STYLES={"Орбита","Капсулы","Минимал"};
    public boolean enabled=true,placed=false;
    public int style=0;
    public double scale=1,opacity=.78;
    public final double[] groupX={.5,.5,.5},groupY={.022,.073,.124};
    public final boolean[] visible=new boolean[IDS.length];
    /** Normalised positions within available width/height, not raw pixels. */
    public final double[] x=new double[IDS.length],y=new double[IDS.length];
    public HudConfig(){Arrays.fill(visible,true);resetPositions();}
    public void resetPositions(){placed=false;Arrays.fill(groupX,.5);groupY[0]=.022;groupY[1]=.073;groupY[2]=.124;
        double[] dx={.02,.26,.42,.02,.52,.02,.7,.02,.02};
        double[] dy={.025,.025,.025,.12,.12,.215,.215,.32,.44};
        System.arraycopy(dx,0,x,0,x.length);System.arraycopy(dy,0,y,0,y.length);
    }
    public void validate(){style=Math.max(0,Math.min(2,style));scale=Settings.clamp(scale,.65,1.6);opacity=Settings.clamp(opacity,.15,1);for(int i=0;i<3;i++){groupX[i]=Settings.clamp(groupX[i],0,1);groupY[i]=Settings.clamp(groupY[i],0,1);}for(int i=0;i<x.length;i++){x[i]=Settings.clamp(x[i],0,1);y[i]=Settings.clamp(y[i],0,1);}}
    public void load(Properties p){
        placed=bool(p,"hud.placed",false);enabled=bool(p,"hud.enabled",true);style=(int)num(p,"hud.style",0);scale=num(p,"hud.scale",1);opacity=num(p,"hud.opacity",.78);
        for(int i=0;i<IDS.length;i++){visible[i]=bool(p,"hud."+IDS[i]+".visible",true);x[i]=num(p,"hud."+IDS[i]+".x",x[i]);y[i]=num(p,"hud."+IDS[i]+".y",y[i]);}
        for(int i=0;i<3;i++){groupX[i]=num(p,"hud.group"+i+".x",.5);groupY[i]=num(p,"hud.group"+i+".y",groupY[i]);}
        // Version 0.1.4 stored oversized fixed-width boxes; reset layout once, not feature switches.
        if(!"2".equals(p.getProperty("hud.layoutVersion"))){style=0;resetPositions();}
        validate();
    }
    public void save(Properties p){validate();p.setProperty("hud.layoutVersion","2");for(int i=0;i<3;i++){p.setProperty("hud.group"+i+".x",""+groupX[i]);p.setProperty("hud.group"+i+".y",""+groupY[i]);}p.setProperty("hud.placed",""+placed);p.setProperty("hud.enabled",""+enabled);p.setProperty("hud.style",""+style);p.setProperty("hud.scale",""+scale);p.setProperty("hud.opacity",""+opacity);for(int i=0;i<IDS.length;i++){String k="hud."+IDS[i];p.setProperty(k+".visible",""+visible[i]);p.setProperty(k+".x",""+x[i]);p.setProperty(k+".y",""+y[i]);}}
    private static double num(Properties p,String k,double fallback){try{double v=Double.parseDouble(p.getProperty(k,""));return Double.isFinite(v)?v:fallback;}catch(NumberFormatException ex){return fallback;}}
    private static boolean bool(Properties p,String k,boolean f){String v=p.getProperty(k);return "true".equals(v)||(!"false".equals(v)&&f);}
}
