package dev.luma.core;

import java.util.*;
import java.util.function.*;
import static dev.luma.core.Canvas.*;

/** Shared by Minecraft and the desktop preview. All pointer hits use the rendered transform. */
public final class Menu {
    // Physical-pixel workspace; height is a viewport, never a reason to shrink all text.
    private final MenuParticles particles=new MenuParticles();
    private int selectedHand;private double pointerY,realDt,previewClock;
    private static final String[] ANIMATIONS={"Smooth","Fade","Slide + Fade","Scale","Zoom","Off"};
    private double W=1000,H=720,bodyX=214,bodyW=762,viewTop=128,viewBottom=680;
    private double scroll,maxScroll;
    private final SmoothScroll scrolling=new SmoothScroll();
    private boolean inContent,compact;
    private static final int WHITE=0xFFF1F1F8, MUTED=0xFFADB0C4, FAINT=0xFFADB0C4;
    public final Settings settings;
    private final double[] waveSamples=new double[97];
    private final Map<String,Motion.Values> animations=new HashMap<>();
    private final List<Hit> hits=new ArrayList<>();
    private double mx=-1000,my=-1000,dt=.016,time,open,tabBlend=1,entryTime,contentSlide;
    private int pendingTab=-1,lastWidth,lastHeight;private boolean rendered,leaving;
    private static final String[] NAV_IDS={"nav0","nav1","nav2","nav3","nav4","nav5","nav6","nav7"};
    private final List<Option> appearanceOptions,backgroundOptions,utilityOptions,visualOptions;
    private List<Option> visibleOptions;private String cachedQuery;private int cachedTab=-1;
    private double ox,oy,unit=1,drawScale=1,accentR=165,accentG=153,accentB=255;
    private double dragOx,dragUnit;
    private boolean closing,changed,searchFocus;
    private String query="",focus="",status="Настройки сохраняются автоматически";
    private Hit drag;
    private int tab;
    private boolean hudRequested;
    private boolean toolSettingsOpen;
    private double toolOpen;
    public boolean takeHudRequested(){boolean v=hudRequested;hudRequested=false;return v;}
    private record Hit(String id,double x,double y,double w,double h,Runnable click,DoubleConsumer slide,DoubleSupplier value,boolean content){
        boolean contains(double px,double py){return px>=x&&py>=y&&px<x+w&&py<y+h;}
    }
    private record Option(String id,String name,String detail,String icon,BooleanSupplier get,Consumer<Boolean> set){}
    public Menu(Settings settings){this.settings=settings;if(!settings.customAccent)AccentColor.fromRgb(settings.accentColor(),settings);int a=settings.uiAccentColor();accentR=a>>16;accentG=(a>>8)&255;accentB=a&255;
        appearanceOptions=optionList(0);backgroundOptions=optionList(1);utilityOptions=createUtilities();
        visualOptions=List.of(new Option("customSkinEnabled","Custom Skin","Локальный облик · скелет в мантии с катаной","spark",()->settings.customSkinEnabled,v->settings.customSkinEnabled=v),
            new Option("saturationEnabled","Насыщенность мира","Приглушённые или более сочные цвета","sun",()->settings.saturationEnabled,v->settings.saturationEnabled=v));
    }
    public void requestClose(){settings.viewModelPreview=false;settings.previewSwing=false;closing=true;searchFocus=false;focus="";release();}
    public boolean closed(){return closing&&open<.012;}
    public boolean isClosing(){return closing;}
    public boolean takeChanged(){boolean b=changed;changed=false;return b;}
    public int tab(){return pendingTab>=0?pendingTab:tab;}
    public void setTab(int value){
        if(closing)return;int next=Math.max(0,Math.min(7,value));if(next==tab())return;
        release();focus="";searchFocus=false;hits.clear();
        if(!rendered||!settings.animated()){applyTab(next);return;}
        if(next==tab){pendingTab=-1;leaving=false;return;}
        pendingTab=next;leaving=true;
    }
    private void applyTab(int next){
        if(next!=7){settings.viewModelPreview=false;settings.previewSwing=false;}tab=next;pendingTab=-1;leaving=false;tabBlend=0;entryTime=0;
        jumpScroll(0);query="";cachedQuery=null;searchFocus=false;focus="";release();hits.clear();
    }
    public double openness(){return open;}
    public double transitionOpacity(){return tabBlend;}
    public boolean transitioning(){return leaving||tabBlend<.9999;}
    public void saveError(){status="Не удалось сохранить: проверь права на config";}
    public void saved(){status="Настройки сохранены на этом устройстве";}
    public void render(Canvas c,int width,int height,double mouseX,double mouseY,double elapsed){
        realDt=Motion.delta(elapsed);dt=realDt*.28/settings.animationDuration;boolean animate=settings.animated();
        if(settings.viewModelPreview&&settings.previewSwing){previewClock=(previewClock+realDt)%1.6;settings.previewProgress=Math.min(1,previewClock/.75);}else{previewClock=0;settings.previewProgress=0;}
        if(width!=lastWidth||height!=lastHeight){release();lastWidth=width;lastHeight=height;}rendered=true;
        open=Motion.approach(open,closing?0:1,closing?Motion.EXIT_RESPONSE:Motion.RESPONSE,dt,animate);
        if(leaving){tabBlend=Motion.approach(tabBlend,0,Motion.EXIT_RESPONSE,dt,animate);if(tabBlend<.025||!animate)applyTab(pendingTab);}
        else tabBlend=Motion.approach(tabBlend,1,Motion.RESPONSE,dt,animate);
        if(!animate&&pendingTab>=0)applyTab(pendingTab);if(!animate)tabBlend=1;
        if(!leaving&&!closing)entryTime=Math.min(1,entryTime+Motion.delta(dt));
        contentSlide=Motion.styleContentSlide(settings.animationStyle,tabBlend,leaving,settings.animationIntensity);
        toolOpen=Motion.approach(toolOpen,toolSettingsOpen?1:0,Motion.RESPONSE,dt,animate);
        if(!settings.reduced)time+=realDt*settings.speed;
        int target=settings.uiAccentColor();
        accentR=Motion.approach(accentR,(target>>16)&255,Motion.RESPONSE,dt,animate);
        accentG=Motion.approach(accentG,(target>>8)&255,Motion.RESPONSE,dt,animate);
        accentB=Motion.approach(accentB,target&255,Motion.RESPONSE,dt,animate);
        int accent=accent();
        background(c,width,height,accent,open);
        // A wider viewport reveals more content; it does not force the whole menu to fit.
        double base=Settings.clamp(Math.min(width/1440.0,height/900.0),.90,1.60);
        double requestedUnit=base*settings.scale;
        // Keep the scale slider under the pointer; apply resize when the drag ends.
        if(drag!=null&&drag.id.equals("scale"))requestedUnit=unit;
        unit=Math.min(requestedUnit,Math.min((width-24.0)/620,(height-24.0)/330));
        unit=Math.max(.08,unit);
        W=Math.min(1060,(width-24.0)/unit);
        H=Math.min(760,(height-24.0)/unit);
        if(settings.viewModelPreview&&tab==7)W=Math.min(W,580);compact=W<900;
        bodyX=compact?94:218;bodyW=W-bodyX-28;
        viewTop=tab<2?160:110;viewBottom=H-48;
        double intensity=settings.animationIntensity;drawScale=unit*Motion.styleScale(settings.animationStyle,open,intensity);
        ox=(width-W*drawScale)/2;oy=(height-H*drawScale)/2+Motion.styleSlide(settings.animationStyle,open,intensity)*unit;if(settings.viewModelPreview&&tab==7)ox=12;
        mx=(mouseX-ox)/drawScale;my=(mouseY-oy)/drawScale;
        if(drag!=null){dragOx=ox;dragUnit=drawScale;}
        hits.clear();
        c.push(ox,oy,drawScale,Motion.styleAlpha(settings.animationStyle,open));
        for(int i=4;i>=1;i--)c.round(-i*2,-i,W+i*4,H+i*2,18+i,alpha(0x000000,.025));
        c.round(-1,-1,W+2,H+2,19,alpha(accent,.24));
        c.round(0,0,W,H,18,alpha(0x10121D,settings.opacity));
        c.round(10,10,compact?68:188,H-20,12,alpha(0x080B13,.53));
        sidebar(c,accent);c.push(0,contentSlide,1,tabBlend);header(c,accent);c.pop();palette(c,accent);
        maxScroll=Math.max(0,measureContent()-viewBottom);
        scrolling.bounds(maxScroll);
        scroll=scrolling.update(dt,smoothScrolling());
        c.clip(bodyX-4,viewTop,bodyW+12,viewBottom-viewTop);
        c.push(0,-scroll+contentSlide,1,tabBlend);inContent=true;
        if(tab<2)options(c,accent);else if(tab==2)modules(c,accent);else if(tab==3)about(c,accent);else if(tab==6)visuals(c,accent);else if(tab==7)viewModel(c,accent);else inspector(c,accent);
        inContent=false;c.pop();c.unclip();
        if(maxScroll>0){
            double vh=viewBottom-viewTop,thumb=Math.max(28,vh*vh/(vh+maxScroll));
            c.round(W-13,viewTop,4,vh,2,alpha(accent,.12));
            c.round(W-13,viewTop+(vh-thumb)*scroll/maxScroll,4,thumb,2,alpha(accent,.75));
        }
        c.line(bodyX,H-39,W-28,H-39,1,alpha(0xFFFFFF,.09));
        c.text(ellipsize(c,BuildInfo.label()+" · "+status,bodyW,14),bodyX,H-29,14,MUTED);
        c.pop();
    }
    private double measureContent(){
        if(tab<2)return viewTop+8+filteredOptions().size()*108+(query.isEmpty()?(tab==0?410:950):66);
        if(tab==2)return viewTop+8+6*108+4*108+100+toolOpen*312;
        if(tab==7)return viewTop+8+2172;
        if(tab==6)return viewTop+8+560;
        if(tab==3)return viewTop+8+150+4*116;
        return viewTop+8+1130;
    }

    private int accent(){return 0xFF000000|((int)accentR<<16)|((int)accentG<<8)|(int)accentB;}
    private double anim(String id,int channel,double target){
        Motion.Values values=animations.get(id);if(values==null){values=new Motion.Values();animations.put(id,values);}
        return values.to(channel,target,dt,settings.animated(),channel==0||channel==2?0:target);
    }
    private boolean over(double x,double y,double w,double h){double py=my+(inContent?scroll-contentSlide:0);return (!inContent||(my>=viewTop&&my<viewBottom))&&mx>=x&&py>=y&&mx<x+w&&py<y+h;}
    private void add(String id,double x,double y,double w,double h,Runnable action){if(!inContent&&id.equals("search")&&(leaving||tabBlend<.5))return;hits.add(new Hit(id,x,y+(id.equals("search")?contentSlide:0),w,h,action,null,null,inContent));}
    private void focusOutline(Canvas c,String id,double x,double y,double w,double h,double radius){
        if(!focus.equals(id))return;
        c.round(x-2,y-2,w+4,h+4,radius+2,alpha(accent(),.70));
        c.round(x-1,y-1,w+2,h+2,radius+1,0xFF111420);
    }
    private void background(Canvas c,int w,int h,int a,double fade){
        if(settings.viewModelPreview&&tab==7)return;
        c.rect(0,0,w,h,alpha(0x050812,(settings.dim?.70:.07)*fade));
        if(!settings.background)return;
        particles.render(c,w,h,settings,realDt,a,fade);c.push(0,0,1,fade);
        if(settings.glow){
            c.glow(w*.23,h*.15,w*.40,a,.14);
            c.glow(w*.86,h*.70,w*.35,a,.10);
        }
        if(settings.dots){
            int budget=settings.efficientBackground?900:1800;
            int spacing=Math.max(18,(int)Math.ceil(Math.sqrt(w*(double)h/budget))),count=0;
            for(int yy=spacing/2;yy<h;yy+=spacing)for(int xx=spacing/2;xx<w&&count<budget;xx+=spacing){c.dot(xx,yy,.6,alpha(a,.14));count++;}
        }
        if(settings.scanlines){for(int y=0;y<h;y+=Math.max(4,(int)Math.ceil(h/(settings.efficientBackground?240.0:480.0))))c.rect(0,y,w,1,alpha(a,.055));}
        if(settings.waves){
            double s=w/1400.0;int steps=settings.efficientBackground?64:96;
            for(int wave=0;wave<3;wave++){
                for(int i=0;i<=steps;i++)waveSamples[i]=waveY(w*i/(double)steps,w,h,wave);
                for(int layer=0;layer<(settings.glow?(settings.efficientBackground?2:3):1);layer++){
                    double thick=layer==0?1.1:layer==1?4.5:13;
                    double al=layer==0?.38:layer==1?.045:.012;
                    double px=0,py=waveSamples[0];
                    for(int i=1;i<=steps;i++){
                        double x=w*i/(double)steps,y=waveSamples[i];
                        c.line(px,py,x,y,thick*s,alpha(a,al));px=x;py=y;
                    }
                }
                double gx=w*(.12+wave*.36+.025*Math.sin(time*.3+wave));double gy=waveY(gx,w,h,wave);
                if(settings.glow)c.glow(gx,gy,38*s,a,.6);
                c.line(gx-7*s,gy,gx+7*s,gy,.8*s,alpha(0xFFFFFF,.60));
                c.line(gx,gy-8*s,gx,gy+8*s,.8*s,alpha(0xFFFFFF,.60));
            }
        }
        if(settings.rings){
            for(int i=0;i<(settings.efficientBackground?10:15);i++){
                double xx=((i*0.6180339887+.04)%1)*w+Math.sin(time*.22+i)*9;
                double yy=((i*.381966+.13+time*.008*(i%2==0?1:-1))%1+1)%1*h;
                double rr=(7+(i*7%17))*w/1400.0;
                c.ring(xx,yy,rr,1.1*w/1400.0,alpha(a,.14+(i%3)*.09));
            }
        }
        c.pop();
    }
    private double waveY(double x,int w,int h,int i){
        return h*(.43+.19*Math.sin(x/w*5.8+time*.19+i*1.9)+.08*Math.sin(x/w*9-time*.13+i));
    }
    private void palette(Canvas c,int a){
        double x=W-48;
        focusOutline(c,"close",x,20,32,40,8);
        c.round(x,20,32,40,8,alpha(a,.08));
        icon(c,"close","close",x+6,30,20,MUTED);
        add("close",x,20,32,40,this::requestClose);
    }
    private void sidebar(Canvas c,int a){
        double navW=compact?52:168;
        c.round(24,26,40,40,11,alpha(a,.12));c.text("LV",29,32,23,a);
        if(!compact){c.text("LUME",76,25,25,WHITE);c.text("VISUALS",78,57,14,MUTED);}
        String[] titles={"Оформление","Фон меню","Утилиты","О проекте","Настройки","HUD","Визуалы","View Model"};
        String[] glyphs={"sliders","wave","grid","info","sun","sliders","spark","cursor"};
        double step=Math.min(58,(H-132)/8);
        for(int i=0;i<8;i++){
            int idx=i;double y=100+i*step;
            double hv=anim(NAV_IDS[i],0,over(18,y,navW,step-6)&&settings.hover?1:0);
            double active=anim(NAV_IDS[i],1,tab()==i?1:0);
            focusOutline(c,NAV_IDS[i],18,y,navW,step-6,9);
            c.round(18,y,navW,step-6,9,alpha(a,.025+active*.105+hv*.035));
            if(active>.01)c.round(18,y+10,3,Math.max(4,step-26),1,alpha(a,active));
            icon(c,NAV_IDS[i],glyphs[i],32,y+(step-6-Math.min(24,step-12))/2,Math.min(24,step-12),mix(MUTED,a,active));
            if(!compact)c.text(titles[i],65,y+(step-6-18)/2-2,17,mix(MUTED,WHITE,active));
            add(NAV_IDS[i],18,y,navW,step-6,()->{if(idx==5)hudRequested=true;else setTab(idx);});
        }
        if(!compact&&H>660){
            c.text("Меньше шума.",28,H-112,17,MUTED);
            c.text("Больше стиля.",28,H-86,17,MUTED);
            c.text(ellipsize(c,BuildInfo.label(),164,12),28,H-46,12,a);
        }
    }
    private void header(Canvas c,int a){
        String[] titles={"Оформление","Атмосфера меню","Утилиты","О проекте","Твой пресет","HUD","Визуалы мира","View Model"};
        c.text(titles[tab],bodyX,24,28,WHITE);
        String sub=tab==7?"Первое лицо · визуальные настройки":tab==4?"Крупнее. Спокойнее. По-твоему.":tab==2?"Удобство в мире. Знакомый стиль.":"Твой стиль. Твои правила.";
        c.text(ellipsize(c,sub,bodyW-4,16),bodyX,67,16,MUTED);c.line(bodyX,94,bodyX+bodyW,94,1,alpha(a,.20));
        if(tab<2){
            focusOutline(c,"search",bodyX,106,bodyW,42,9);
            c.round(bodyX,106,bodyW,42,9,alpha(a,searchFocus?.10:.045));
            Icons.draw(c,"search",bodyX+14,117,20,MUTED);
            String display=query.isEmpty()?(searchFocus?"Начни вводить…":"Найти настройку · Ctrl + F"):query;
            c.text(ellipsize(c,display,bodyW-62,17),bodyX+46,115,17,query.isEmpty()?MUTED:WHITE);
            if(searchFocus&&((int)(time*2)%2==0))c.rect(bodyX+46+c.textWidth(ellipsize(c,query,bodyW-66,17),17)+2,116,1,22,a);
            add("search",bodyX,106,bodyW,42,()->{searchFocus=true;focus="search";});
        }
    }
    private List<Option> optionList(int index){
        if(index==0)return List.of(
            new Option("motion","Плавные анимации","Открытие и переходы","spark",()->settings.motion,v->settings.motion=v),
            new Option("smoothScroll","Плавная прокрутка","Мягкое движение без рывков","sliders",()->settings.smoothScroll,v->settings.smoothScroll=v),
            new Option("proximity","Живые иконки","Реакция на близость курсора","cursor",()->settings.proximity,v->settings.proximity=v),
            new Option("hover","Мягкое наведение","Подсветка кнопок и карточек","sun",()->settings.hover,v->settings.hover=v),
            new Option("background","Анимированный фон","Общий переключатель фона","wave",()->settings.background,v->settings.background=v),
            new Option("glow","Мягкое свечение","Деликатные световые акценты","ring",()->settings.glow,v->settings.glow=v),
            new Option("reduced","Меньше движения","Статика вместо анимации","pause",()->settings.reduced,v->settings.reduced=v));
        return List.of(
            new Option("waves","Световые волны","Плавные линии за панелями","wave",()->settings.waves,v->settings.waves=v),
            new Option("rings","Парящие кольца","Лёгкий геометрический фон","ring",()->settings.rings,v->settings.rings=v),
            new Option("scanlines","Скан-линии","Тонкая текстура экрана","sliders",()->settings.scanlines,v->settings.scanlines=v),
            new Option("dots","Сетка точек","Ритм и глубина без шума","grid",()->settings.dots,v->settings.dots=v),
            new Option("dim","Затемнение мира","Меньше отвлечений за меню","sun",()->settings.dim,v->settings.dim=v),
            new Option("background","Показывать фон","Выключить все фоновые эффекты","pause",()->settings.background,v->settings.background=v),
            new Option("efficientBackground","Лёгкий фон","Меньше деталей, без потери чёткости меню","sliders",()->settings.efficientBackground,v->settings.efficientBackground=v));
    }
    private List<Option> filteredOptions(){
        if(cachedTab!=tab||!query.equals(cachedQuery)){
            cachedTab=tab;cachedQuery=query;String needle=query.toLowerCase(Locale.ROOT);
            List<Option> source=tab==0?appearanceOptions:backgroundOptions;
            visibleOptions=query.isEmpty()?source:source.stream().filter(o->(o.name+" "+o.detail).toLowerCase(Locale.ROOT).contains(needle)).toList();
        }return visibleOptions;
    }
    private void options(Canvas c,int a){
        List<Option> list=filteredOptions();
        optionCards(c,a,list,viewTop+8);
        double y=viewTop+8+list.size()*108;
        if(list.isEmpty()){c.text("Ничего не найдено",bodyX+16,y+10,22,WHITE);y+=44;}
        if(query.isEmpty()){y+=12;y=tab==0?animationSettings(c,a,y):particleSettings(c,a,y);}
        String note=settings.reduced?"Режим покоя: фон статичен, переходы мгновенные.":tab==0?"Подвед�� курсор к иконке — она мягко откликнется.":!settings.background?"Фон отключён. Выбранные эффекты сохранены.":"Эти эффекты видны только при открытом меню.";
        wrapped(c,note,bodyX+4,y+8,bodyW-16,16,MUTED);
    }
    private void optionCards(Canvas c,int a,List<Option> list,double top){optionCards(c,a,list,top,0,list.size());}
    private void optionCards(Canvas c,int a,List<Option> list,double top,int from,int end){
        for(int i=from;i<end;i++){
            Option o=list.get(i);double x=bodyX,y=top+(i-from)*108;
            add(o.id,x,y,bodyW,96,()->{o.set.accept(!o.get.getAsBoolean());changed=true;});
            if(y+98-scroll<viewTop||y-2-scroll>viewBottom)continue;
            double reveal=tab<2?Motion.stagger(entryTime,i,settings.animated()):1;
            c.push(0,0,1,reveal);
            double hv=anim(o.id,0,over(x,y,bodyW,96)&&settings.hover?1:0);
            double on=anim(o.id,1,o.get.getAsBoolean()?1:0);
            focusOutline(c,o.id,x,y,bodyW,96,11);
            c.round(x-1,y-1,bodyW+2,98,12,alpha(a,.13+hv*.12));c.round(x,y,bodyW,96,11,0xFF171925);c.round(x,y,bodyW,96,11,alpha(a,.035+hv*.035+on*.02));c.line(x+14,y+1,x+bodyW-14,y+1,1,alpha(0xFFFFFF,.045));
            c.round(x+14,y+18,42,42,10,alpha(a,.055+on*.065));
            icon(c,o.id,o.icon,x+23,y+27,24,mix(MUTED,a,on));
            c.text(o.name,x+72,y+15,21,WHITE);
            wrapped(c,o.detail,x+72,y+49,bodyW-152,16,MUTED);
            double th=anim(o.id,2,over(x+bodyW-66,y+17,56,48)&&settings.hover?1:0);
            c.push(x+bodyW-38,y+40,1+th*.07,1);
            c.round(-23,-12,46,24,12,mix(0xFF343849,a,on));
            c.circle(-11+on*22,0,8,mix(0xFFA9AEC1,WHITE,on));c.pop();c.pop();
        }
    }
    private void inspector(Canvas c,int a){
        double x=bodyX,y=viewTop+8;
        c.text("Цветовая тема",x,y,21,WHITE);
        c.text((settings.customAccent?"Custom":Settings.NAMES[settings.theme]),x+bodyW-c.textWidth((settings.customAccent?"Custom":Settings.NAMES[settings.theme]),18),y+2,18,a);
        for(int i=0;i<Settings.COLORS.length;i++){
            final int j=i;double xx=x+26+i*58;
            if(settings.theme==i)c.ring(xx,y+62,19,1.5,a);
            c.circle(xx,y+62,13,0xFF000000|Settings.COLORS[i]);
            if(settings.theme==i)Icons.draw(c,"check",xx-8,y+54,16,0xFF15151F);
            if(focus.equals("theme"+i))c.ring(xx,y+62,23,1,WHITE);
            add("theme"+i,xx-24,y+38,48,48,()->{settings.theme=j;settings.customAccent=false;AccentColor.fromRgb(settings.accentColor(),settings);changed=true;});
        }
        slider(c,"scale","Размер интерфейса",y+112,()->(settings.scale-Settings.MIN_SCALE)/(Settings.MAX_SCALE-Settings.MIN_SCALE),v->settings.scale=Settings.MIN_SCALE+v*(Settings.MAX_SCALE-Settings.MIN_SCALE),Math.round(settings.scale*100)+"%",a);
        wrapped(c,"Ctrl + 0 — вернуть 100%. На небольшом экране используй прокрутку.",x,y+202,bodyW,16,MUTED);
        slider(c,"speed","Скорость фона",y+282,()->(settings.speed-.35)/1.45,v->settings.speed=.35+v*1.45,String.format(Locale.ROOT,"%.2f×",settings.speed),a);
        slider(c,"opacity","Плотность панелей",y+400,()->(settings.opacity-.82)/.18,v->settings.opacity=.82+v*.18,Math.round(settings.opacity*100)+"%",a);
        double by=y+526;
        double hv=anim("reset",0,over(x,by,bodyW,52)&&settings.hover?1:0);
        focusOutline(c,"reset",x,by,bodyW,52,9);
        c.round(x,by,bodyW,52,9,alpha(a,.075+hv*.06));
        String label="Сбросить оформление";
        c.text(label,x+(bodyW-c.textWidth(label,19))/2,by+12,19,WHITE);
        add("reset",x,by,bodyW,52,()->{settings.reset();changed=true;status="Стандартное оформление восстановлено";});
        colorPicker(c,a,y+606);
    }
private double animationSettings(Canvas c,int a,double y){
choice(c,"animationStyle","Стиль анимации",ANIMATIONS[settings.animationStyle],y,()->{settings.animationStyle=(settings.animationStyle+1)%6;changed=true;release();},a);y+=108;
slider(c,"animationDuration","Длительность перехода",y,()->(settings.animationDuration-0.12)/(0.65-0.12),v->{settings.animationDuration=.12+v*.53;},Math.round(settings.animationDuration*1000)+" мс",a);y+=104;
slider(c,"animationIntensity","Сила движения",y,()->(settings.animationIntensity-0)/(1.0-0),v->{settings.animationIntensity=v;},Math.round(settings.animationIntensity*100)+"%",a);y+=104;
return y;}
private double particleSettings(Canvas c,int a,double y){
choice(c,"particleStyle","Частицы меню",MenuParticles.STYLES[settings.particleStyle],y,()->{settings.particleStyle=(settings.particleStyle+1)%5;changed=true;},a);y+=108;
slider(c,"particleAmount","Количество",y,()->(settings.particleAmount-0)/(64.0-0),v->{settings.particleAmount= (int)Math.round(v*64);},String.format(Locale.ROOT,"%.2f",(double)settings.particleAmount),a);y+=104;
slider(c,"particleSpeed","Скорость частиц",y,()->(settings.particleSpeed-0.1)/(2-0.1),v->{settings.particleSpeed=0.1+v*(2-0.1);},String.format(Locale.ROOT,"%.2f",(double)settings.particleSpeed),a);y+=104;
slider(c,"particleSize","Размер частиц",y,()->(settings.particleSize-0.5)/(3-0.5),v->{settings.particleSize=0.5+v*(3-0.5);},String.format(Locale.ROOT,"%.2f",(double)settings.particleSize),a);y+=104;
slider(c,"particleOpacity","Непрозрачность",y,()->(settings.particleOpacity-0.05)/(0.5-0.05),v->{settings.particleOpacity=0.05+v*(0.5-0.05);},String.format(Locale.ROOT,"%.2f",(double)settings.particleOpacity),a);y+=104;
choice(c,"particleDirection","Направление",MenuParticles.DIRECTIONS[settings.particleDirection],y,()->{settings.particleDirection=(settings.particleDirection+1)%4;changed=true;},a);y+=108;
choice(c,"particleAccent","Цвет частиц",settings.particleAccent?"Следовать акценту":"Сохранённый цвет",y,()->{settings.particleAccent=!settings.particleAccent;changed=true;},a);y+=108;
choice(c,"particleColor","Взять цвет из палитры","Сохранить текущий акцент",y,()->{settings.particleColor=settings.accentColor();settings.particleAccent=false;changed=true;},a);y+=108;
return y;}
private void colorPicker(Canvas c,int a,double y){
 c.text("Палитра акцента",bodyX,y,21,WHITE);String hex=String.format(Locale.ROOT,"#%06X",settings.accentColor());c.text(hex,bodyX+bodyW-c.textWidth(hex,18),y,18,a);y+=38;double h=156,w=bodyW;
 if(y+h-scroll>=viewTop&&y-scroll<=viewBottom){c.gradient(bodyX,y,w,h,0xFFFFFFFF,0xFF000000|AccentColor.rgb(settings.accentHue,1,1),false);c.gradient(bodyX,y,w,h,0x00000000,0xFF000000,true);double px=bodyX+settings.accentSaturation*w,py=y+(1-settings.accentValue)*h;c.ring(px,py,6,2,0xFF10121D);c.ring(px,py,4,1.5,WHITE);}
 hits.add(new Hit("accentSV",bodyX,y,w,h,()->{},v->{},()->settings.accentSaturation,true));y+=180;
 slider(c,"accentHue","Оттенок",y,()->settings.accentHue,v->{settings.accentHue=v;settings.customAccent=true;},Math.round(settings.accentHue*360)+"°",a);y+=98;
 choice(c,"customAccent","Источник акцента",settings.customAccent?"Custom · палитра":"Готовая тема",y,()->{settings.customAccent=!settings.customAccent;changed=true;},a);
 wrapped(c,"Тёмные акценты осветляются для читаемости.",bodyX,y+108,bodyW,14,MUTED);
}
private void viewModel(Canvas c,int a){var vm=settings.viewModel;var pose=selectedHand==0?vm.main:vm.off;double y=viewTop+8;
choice(c,"viewModelEnabled","View Model",vm.enabled?"ON · визуальные трансформации":"OFF · Vanilla",y,()->{vm.enabled=!vm.enabled;changed=true;},a);y+=108;
choice(c,"viewModelPreview","Живой предпросмотр",settings.viewModelPreview?"Закрыть боковую панель":"Показать руки в текущем мире",y,()->{settings.viewModelPreview=!settings.viewModelPreview;release();hits.clear();},a);y+=108;
choice(c,"viewModelHand","Настраиваемая рука",selectedHand==0?"Main Hand · основная":"Off Hand · вторая",y,()->{selectedHand=1-selectedHand;release();hits.clear();},a);y+=108;
choice(c,"viewModelPreset","Пресет руки",ViewModelConfig.PRESETS[pose.preset],y,()->{pose.preset((pose.preset+1)%6);changed=true;},a);y+=108;
slider(c,"vmHorizontal","Влево / Вправо",y,()->(pose.horizontal- -0.8)/(0.8- -0.8),v->{pose.horizontal=-0.8+v*(0.8- -0.8);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.horizontal),a);y+=104;
slider(c,"vmVertical","Вниз / Вверх",y,()->(pose.vertical- -0.8)/(0.8- -0.8),v->{pose.vertical=-0.8+v*(0.8- -0.8);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.vertical),a);y+=104;
slider(c,"vmDistance","Ближе / Дальше",y,()->(pose.distance- -0.8)/(0.8- -0.8),v->{pose.distance=-0.8+v*(0.8- -0.8);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.distance),a);y+=104;
slider(c,"vmScale","Меньше / Больше",y,()->(pose.scale-0.4)/(1.6-0.4),v->{pose.scale=0.4+v*(1.6-0.4);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.scale),a);y+=104;
slider(c,"vmTilt","Наклон предмета",y,()->(pose.tilt- -90)/(90.0- -90),v->{pose.tilt=-90+v*(90.0- -90);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.tilt),a);y+=104;
slider(c,"vmYaw","Поворот по горизонтали",y,()->(pose.yaw- -90)/(90.0- -90),v->{pose.yaw=-90+v*(90.0- -90);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.yaw),a);y+=104;
slider(c,"vmPitch","Поворот по вертикали",y,()->(pose.pitch- -90)/(90.0- -90),v->{pose.pitch=-90+v*(90.0- -90);pose.preset=5;},String.format(Locale.ROOT,"%.2f",pose.pitch),a);y+=104;
// Swing Animation no longer has its own UI item; the system, styles and Custom sliders below stay active.
slider(c,"swingSpeed","Custom · скорость",y,()->(vm.swingSpeed-0.5)/(2-0.5),v->{vm.swingSpeed=0.5+v*(2-0.5);},String.format(Locale.ROOT,"%.2f",vm.swingSpeed),a);y+=104;
slider(c,"swingStrength","Custom · амплитуда",y,()->(vm.swingStrength-0)/(1.5-0),v->{vm.swingStrength=0+v*(1.5-0);},String.format(Locale.ROOT,"%.2f",vm.swingStrength),a);y+=104;
slider(c,"swingRotation","Custom · поворот",y,()->(vm.swingRotation-0)/(1.5-0),v->{vm.swingRotation=0+v*(1.5-0);},String.format(Locale.ROOT,"%.2f",vm.swingRotation),a);y+=104;
slider(c,"positionInfluence","Custom · смещение",y,()->(vm.positionInfluence-0)/(1.5-0),v->{vm.positionInfluence=0+v*(1.5-0);},String.format(Locale.ROOT,"%.2f",vm.positionInfluence),a);y+=104;
slider(c,"scaleInfluence","Custom · масштаб",y,()->(vm.scaleInfluence-0)/(0.15-0),v->{vm.scaleInfluence=0+v*(0.15-0);},String.format(Locale.ROOT,"%.2f",vm.scaleInfluence),a);y+=104;
choice(c,"equipStyle","Equip Animation",ViewModelConfig.EQUIPS[vm.equipStyle],y,()->{vm.equipStyle=(vm.equipStyle+1)%4;changed=true;},a);y+=108;
choice(c,"previewSwing","Тест движения · без атаки",settings.previewSwing?"Остановить":"Повторять Swing в предпросмотре",y,()->{settings.previewSwing=!settings.previewSwing;settings.viewModelPreview=true;release();hits.clear();},a);y+=108;
wrapped(c,"Предпросмотр использует предметы в руках и свет мира. Включи первое лицо. Карты, арбалет и активное использование сохраняют Vanilla. Custom-ползунки работают в стиле Custom.",bodyX,y,bodyW,16,MUTED);}
    private void slider(Canvas c,String id,String name,double y,DoubleSupplier value,DoubleConsumer setter,String label,int a){
        double x=bodyX,w=bodyW;
        c.text(ellipsize(c,name,w-c.textWidth(label,19)-18,20),x,y,20,WHITE);c.text(label,x+w-c.textWidth(label,19),y+1,19,a);
        double v=value.getAsDouble();
        focusOutline(c,id,x,y+36,w,44,9);
        c.round(x+10,y+56,w-20,6,3,0xFF33374B);
        if(id.equals("accentHue")){for(int i=0;i<6;i++)c.gradient(x+10+(w-20)*i/6,y+54,(w-20)/6,10,0xFF000000|AccentColor.rgb(i/6.0,1,1),0xFF000000|AccentColor.rgb((i+1)/6.0,1,1),false);}else c.round(x+10,y+56,Math.max(6,(w-20)*v),6,3,a);
        double hv=anim(id,2,over(x,y+36,w,44)&&settings.hover?1:0);
        c.circle(x+10+(w-20)*v,y+59,11+hv,alpha(a,.20));
        c.circle(x+10+(w-20)*v,y+59,8,WHITE);
        hits.add(new Hit(id,x+10,y+36,w-20,44,()->{},setter,value,true));
    }
    private List<Option> createUtilities(){
        return List.of(
            new Option("autoSprint","Auto Sprint","Обычный спринт при движении вперёд","cursor",()->settings.autoSprint,v->settings.autoSprint=v),
            new Option("itemScroller","Item Scroller","Shift + ЛКМ: проводи по слотам","grid",()->settings.itemScroller,v->settings.itemScroller=v),
            new Option("dropProtection","Защита вы��расывания","Два нажатия кнопки выбрасывания за 0,5 с","check",()->settings.dropProtection,v->settings.dropProtection=v),
            new Option("toolSafety","Защита инструментов","Настройки слева · включение справа","check",()->settings.toolSafety,v->settings.toolSafety=v),
            new Option("durabilityWarning","Предупреждение о поломке","Броня и предметы в руках · без спама","info",()->settings.durabilityWarning,v->settings.durabilityWarning=v),
            new Option("ratioEnabled","Ratio Size","Растяжка мира. Меню и HUD — обычные","sliders",()->settings.ratioEnabled,v->settings.ratioEnabled=v));
    }
    private void modules(Canvas c,int a){
        double x=bodyX,y=viewTop+8;
        for(int index=0;index<utilityOptions.size();index++){
            Option option=utilityOptions.get(index);optionCards(c,a,utilityOptions,y,index,index+1);
            if(option.id.equals("toolSafety")){
                // Explicit toggle on the right, independent settings button on the left.
                hits.removeIf(hit->hit.id.equals("toolSafety"));
                add("toolSafety",x+bodyW-72,y+12,64,64,()->{settings.toolSafety=!settings.toolSafety;changed=true;});
                focusOutline(c,"toolSafetySettings",x+10,y+14,50,50,10);
                c.round(x+10,y+14,50,50,10,0xFF222333);
                Icons.draw(c,"sliders",x+23,y+26,24,a);
                double yy=y+76;
                c.line(x+25,yy+toolOpen*5,x+33,yy+5-toolOpen*5,1.5,a);
                c.line(x+33,yy+5-toolOpen*5,x+41,yy+toolOpen*5,1.5,a);
                add("toolSafetySettings",x+8,y+8,54,80,()->{toolSettingsOpen=!toolSettingsOpen;drag=null;});
            }
            y+=108;
            if(option.id.equals("toolSafety")&&toolOpen>.001){
                c.clip(x,y,bodyW,312*toolOpen);
                c.push(0,-8*(1-toolOpen),1,toolOpen);
                int hitStart=hits.size();
                c.round(x,y,bodyW,300,11,alpha(a,.055));
                bodyX+=16;bodyW-=32;
                slider(c,"toolSafetyThreshold","Порог прочности",y+12,()->(settings.toolSafetyThreshold-1)/199.0,
                    v->settings.toolSafetyThreshold=1+(int)Math.round(v*199),settings.toolSafetyThreshold+" ед.",a);
                // Moved from the general utilities list: the warning threshold belongs to tool protection.
                choice(c,"durabilityThreshold","Порог предупреждения",settings.durabilityThreshold+"% прочности",y+156,
                    ()->{settings.durabilityThreshold=settings.durabilityThreshold>=30?5:settings.durabilityThreshold+5;changed=true;},a);
                bodyX-=16;bodyW+=32;
                wrapped(c,"Не выше 10% запаса прочности. Убирает инструмент в свободный слот инвентаря; не трогает броню и элитры.",x+16,y+102,bodyW-32,16,MUTED);
                // A clipped / collapsing control must never intercept clicks or keyboard focus.
                if(toolOpen<.999||!toolSettingsOpen)hits.subList(hitStart,hits.size()).clear();
                c.pop();c.unclip();y+=312*toolOpen;
            }
        }
        choice(c,"ratioMode","Режим Ratio Size",settings.ratioMode==0?"Пропорции":"Разрешение",y,
            ()->{settings.ratioMode=1-settings.ratioMode;changed=true;},a);
        y+=108;
        choice(c,"aspectPreset","Пропорции мира",RatioPresets.aspectName(settings.aspectPreset),y,
            ()->{settings.aspectPreset=(settings.aspectPreset+1)%RatioPresets.ASPECT_COUNT;changed=true;},a);
        y+=108;
        choice(c,"resolutionPreset","Разрешение картинки",RatioPresets.resolutionName(settings.resolutionPreset),y,
            ()->{settings.resolutionPreset=(settings.resolutionPreset+1)%RatioPresets.RESOLUTION_COUNT;settings.ratioMode=1;changed=true;},a);
        y+=108;
        choice(c,"ratioReset","Вернуть обычный мир","Выключить Ratio",y,()->{settings.ratioEnabled=false;changed=true;},a);
        y+=108;
        wrapped(c,settings.ratioStatus,x+4,y+4,bodyW-8,16,MUTED);
        wrapped(c,"Разрешение картинки — без ускорения FPS. F8 — выключить Ratio.",x+4,y+44,bodyW-8,16,MUTED);
    }
    private void visuals(Canvas c,int a){
        double y=viewTop+8;
        // Keep the existing settings/control ID and card renderer; put the switch first.
        optionCards(c,a,visualOptions,y,0,1);
        String skinState=settings.customSkinEnabled?"ON":"OFF";
        c.text(skinState,bodyX+bodyW-38-c.textWidth(skinState,14)/2,y+66,14,
            settings.customSkinEnabled?a:MUTED);
        y+=124;
        optionCards(c,a,visualOptions,y,1,2);
        y+=124;
        slider(c,"saturation","Насыщенность",y,()->settings.saturation/1.5,v->{settings.saturation=v*1.5;settings.saturationEnabled=true;},Math.round(settings.saturation*100)+"%",a);
        y+=128;
        choice(c,"saturationReset","Обычные цвета","Вернуть 100% и выключить",y,()->{settings.saturation=1;settings.saturationEnabled=false;changed=true;},a);
        y+=112;
        wrapped(c,settings.saturationStatus,bodyX+4,y,bodyW-8,16,MUTED);
    }
    private void choice(Canvas c,String id,String name,String value,double y,Runnable action,int a){
        double x=bodyX;
        add(id,x,y,bodyW,96,action);
        if(y+98-scroll<viewTop||y-2-scroll>viewBottom)return;
        focusOutline(c,id,x,y,bodyW,96,11);
        double hv=anim(id,0,over(x,y,bodyW,96)&&settings.hover?1:0);
        c.round(x,y,bodyW,96,11,alpha(a,.055+hv*.04));
        c.text(name,x+18,y+12,20,WHITE);
        c.text(value,x+18,y+48,21,a);
        c.line(x+bodyW-32,y+39,x+bodyW-24,y+47,1.7,MUTED);
        c.line(x+bodyW-24,y+47,x+bodyW-32,y+55,1.7,MUTED);
    }
    private void about(Canvas c,int a){
        double x=bodyX,y=viewTop+8;
        c.round(x,y,bodyW,134,12,alpha(a,.075));
        icon(c,"about","logo",x+18,y+20,32,a);
        c.text("LUME VISUALS",x+68,y+16,28,WHITE);
        c.text("Клиентский мод · 0.1.5",x+68,y+61,18,MUTED);
        c.text("Minecraft 1.21.4 / Fabric / Java 21",x+18,y+100,16,MUTED);
        String[][] lines={{"ЧТО УЖЕ РАБОТАЕТ","Темы, плавная прокрутка, Auto Sprint, Shift-перенос и Ratio Size."},{"ЧЕГО ЗДЕСЬ НЕТ","Боевых функций, сетевых сервисов и игровых частиц."},{"УПРАВЛЕНИЕ","Tab — фокус, Enter — выбор, стрелки — сла��дер. Колесо / Page Up / Page Down — прокрутка."},{"ПОИСК И МАСШТАБ","Ctrl + F — поиск. Ctrl + 0 — масштаб 100%. Right Shift / Esc — закрыть."}};
        for(int i=0;i<lines.length;i++){double yy=y+150+i*116;c.text(lines[i][0],x+4,yy,17,a);wrapped(c,lines[i][1],x+4,yy+31,bodyW-8,18,MUTED);}
    }
    private double wrapped(Canvas c,String text,double x,double y,double width,double size,int color){
        String line="";double yy=y;
        for(String word:text.split(" ")){
            String next=line.isEmpty()?word:line+" "+word;
            if(!line.isEmpty()&&c.textWidth(next,size)>width){c.text(line,x,yy,size,color);yy+=size+6;line=word;}else line=next;
        }
        if(!line.isEmpty())c.text(line,x,yy,size,color);
        return yy+size+6;
    }
    private void icon(Canvas c,String id,String glyph,double x,double y,double size,int color){
        double close=settings.proximity&&!settings.reduced?Motion.proximity(x+size/2,y+size/2,mx,my+(inContent?scroll-contentSlide:0),75):0;
        double s=anim(id,3,1+close*.14);
        c.push(x+size/2,y+size/2,s,1);Icons.draw(c,glyph,-size/2,-size/2,size,color);c.pop();
    }
    private String ellipsize(Canvas c,String s,double max,double size){
        if(c.textWidth(s,size)<=max)return s;
        while(!s.isEmpty()&&c.textWidth(s+"…",size)>max)s=s.substring(0,s.length()-1);return s+"…";
    }
    private boolean enabled(Hit hit){
        if(!hit.content)return true;if(leaving||tabBlend<.5)return false;
        if(tab<2){List<Option> options=filteredOptions();for(int i=0;i<options.size();i++)if(options.get(i).id.equals(hit.id))return Motion.stagger(entryTime,i,settings.animated())>=.35;}
        return true;
    }
    public boolean click(double screenX,double screenY,int button){
        if(button!=0||closing||open<.2)return false;
        double x=(screenX-ox)/drawScale,y=(screenY-oy)/drawScale;
        searchFocus=false;pointerY=screenY;
        // Reverse order: topmost control receives the click.
        for(int i=hits.size()-1;i>=0;i--){Hit h=hits.get(i);if(!enabled(h)||h.content&&(y<viewTop||y>=viewBottom))continue;if(!h.contains(x,y+(h.content?scroll-contentSlide:0)))continue;
            focus=h.id;
            if(h.content)jumpScroll(scroll); // Stop drift while interacting with a visible control.
            if(h.slide!=null){drag=h;dragOx=ox;dragUnit=drawScale;slideAt(screenX);}else h.click.run();return true;
        }
        focus="";return false;
    }
    public void move(double screenX,double screenY){pointerY=screenY;if(!closing&&drag!=null)slideAt(screenX);}
    private void slideAt(double screenX){
        double x=(screenX-dragOx)/dragUnit;
        if(drag.id.equals("accentSV")){double y=(pointerY-oy)/drawScale+scroll-contentSlide;settings.accentSaturation=Settings.clamp((x-drag.x)/drag.w,0,1);settings.accentValue=1-Settings.clamp((y-drag.y)/drag.h,0,1);settings.customAccent=true;changed=true;return;}
        drag.slide.accept(Settings.clamp((x-drag.x)/drag.w,0,1));changed=true;
    }
    public void release(){drag=null;}
    public boolean scroll(double screenX,double screenY,double amount){
        double x=(screenX-ox)/drawScale,y=(screenY-oy)/drawScale;
        if(closing||leaving||tabBlend<.5||drag!=null||x<bodyX||x>W||y<viewTop||y>viewBottom)return false;
        scrolling.move(-amount*54,smoothScrolling());scroll=scrolling.value();return true;
    }
    /** Keyboard navigation and regression tests use the same reveal operation. */
    public void revealControl(String id){for(Hit h:hits)if(h.id.equals(id)&&h.content){jumpScroll(h.y-viewTop-8);return;}}
    private boolean smoothScrolling(){return settings.smoothScroll&&settings.animated();}
    private void jumpScroll(double value){scrolling.bounds(maxScroll);scrolling.jump(value);scroll=scrolling.value();}
    public double scrollTarget(){return scrolling.target();}
    public double effectiveScale(){return unit;}
    public double scrollOffset(){return scroll;}
    public double scrollLimit(){return maxScroll;}

    public boolean key(int code,boolean ctrl,boolean shift){
        if(closing)return false;
        if(code==256){if(searchFocus){searchFocus=false;focus="";}else requestClose();return true;}
        if(ctrl&&code==48){settings.scale=1;changed=true;return true;}
        if(ctrl&&code==70){if(tab>1){applyTab(0);tabBlend=1;}searchFocus=true;focus="search";return true;}
        if(open<.2||leaving||tabBlend<.5)return false;
        if(code==266||code==267){scrolling.move((code==267?1:-1)*(viewBottom-viewTop)*.8,smoothScrolling());scroll=scrolling.value();return true;}
        if(code==258){
            if(hits.isEmpty())return true;int idx=-1;for(int i=0;i<hits.size();i++)if(hits.get(i).id.equals(focus))idx=i;
            for(int attempt=0;attempt<hits.size();attempt++){idx=Math.floorMod(idx+(shift?-1:1),hits.size());if(enabled(hits.get(idx)))break;}focus=hits.get(idx).id;searchFocus=focus.equals("search");Hit target=hits.get(idx);
            if(target.content){if(target.y-scroll<viewTop+4)scroll=target.y-viewTop-4;else if(target.y+target.h-scroll>viewBottom-4)scroll=target.y+target.h-viewBottom+4;jumpScroll(scroll);}return true;
        }
        if(searchFocus){if(code==259&&!query.isEmpty())query=query.substring(0,query.length()-1);jumpScroll(0);return true;}
        for(Hit h:hits)if(h.id.equals(focus)&&enabled(h)){
            if(h.id.equals("accentSV")&&code>=262&&code<=265){if(code==262||code==263)settings.accentSaturation=Settings.clamp(settings.accentSaturation+(code==262?.025:-.025),0,1);else settings.accentValue=Settings.clamp(settings.accentValue+(code==265?.025:-.025),0,1);settings.customAccent=true;changed=true;return true;}
            if(h.slide!=null&&(code==262||code==263)){h.slide.accept(Settings.clamp(h.value.getAsDouble()+(code==262?.025:-.025),0,1));changed=true;return true;}
            if(code==257||code==32){h.click.run();return true;}
        }
        return false;
    }
    public boolean character(char ch){if(!closing&&searchFocus&&!Character.isISOControl(ch)&&query.length()<40){query+=ch;jumpScroll(0);return true;}return false;}
    /** Test/preview helpers: uses actual hit regions, not duplicated layout constants. */
    public double[] controlCenter(String id){for(Hit h:hits)if(h.id.equals(id))return new double[]{ox+(h.x+h.w/2)*drawScale,oy+(h.y+h.h/2-(h.content?scroll-contentSlide:0))*drawScale};throw new IllegalArgumentException(id);}
    public List<String> controlIds(){return hits.stream().map(Hit::id).toList();}
}
