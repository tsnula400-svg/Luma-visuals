package dev.luma.core;
/** Fixed arrays, batched primitives, no particle object allocations or textures. */
public final class MenuParticles {
 public static final int MAX=64;
 public static final String[] STYLES={"Off","Soft Dots","Floating","Sparkles","Dust"},DIRECTIONS={"Вверх","Вниз","Вправо","Влево"};
 private final double[] x=new double[MAX],y=new double[MAX],phase=new double[MAX];private double clock;
 public MenuParticles(){for(int i=0;i<MAX;i++){x[i]=(i*.61803398875+.07)%1;y[i]=(i*.41421356237+.17)%1;phase[i]=i*2.399963;}}
 public void render(Canvas c,int w,int h,Settings s,double seconds,int accent,double alpha){if(!s.background||s.particleStyle==0||alpha<.001)return;double dt=s.reduced?0:Motion.delta(seconds);clock=(clock+dt)%10000;int count=Math.min(s.efficientBackground?40:MAX,Math.max(0,s.particleAmount));double speed=s.particleSpeed*(s.particleStyle==4?.3:1),dx=s.particleDirection==2?1:s.particleDirection==3?-1:0,dy=s.particleDirection==0?-1:s.particleDirection==1?1:0;int col=s.particleAccent?accent:s.particleColor;
 for(int i=0;i<count;i++){double drift=dt*speed*(8+i%7);x[i]=wrap(x[i]+dx*drift/Math.max(1,w));y[i]=wrap(y[i]+dy*drift/Math.max(1,h));double px=x[i]*w,py=y[i]*h;if(s.particleStyle==2)px+=Math.sin(clock*.5+phase[i])*8;double opacity=s.particleOpacity*alpha*(s.particleStyle==3?.55+.45*Math.sin(clock+phase[i]):.75),size=s.particleSize*(.65+i%4*.12);int a=Canvas.alpha(col,opacity);if(s.particleStyle==3){c.rect(px-size,py-.6,2*size,1.2,a);c.rect(px-.6,py-size,1.2,2*size,a);}else c.dot(px,py,size*(s.particleStyle==4?.5:1),a);}}
 private static double wrap(double n){return n-Math.floor(n);}
}
