package dev.luma.core;
public final class Icons {
    private Icons(){}
    public static void draw(Canvas c,String name,double x,double y,double size,int color){
        c.push(x,y,size/24,1);
        switch(name){
            case "person", "people" -> {c.circle(10,7,3,color);c.round(4,12,12,8,3,color);if(name.equals("people")){c.circle(18,8,2,color);c.line(18,13,21,18,2,color);}}
            case "monitor" -> {c.round(2,3,20,14,3,color);c.round(4,5,16,10,1,0xFF202637);c.line(8,21,16,21,1.5,color);c.line(12,17,12,21,1.5,color);c.line(6,12,10,8,1.5,color);c.line(10,8,13,11,1.5,color);c.line(13,11,18,7,1.5,color);}
            case "signal" -> {for(int i=0;i<3;i++)c.round(3+i*7,17-i*5,4,5+i*5,1,color);}
            case "compass" -> {c.ring(12,12,9,1.4,color);c.line(8,16,10,9,1.5,color);c.line(10,9,16,7,1.5,color);c.line(16,7,14,14,1.5,color);c.line(14,14,8,16,1.5,color);}
            case "speed" -> {c.line(2,7,10,7,1.5,color);c.line(2,12,8,12,1.5,color);c.line(2,17,10,17,1.5,color);c.line(12,5,20,12,1.5,color);c.line(20,12,12,19,1.5,color);}
            case "server" -> {c.round(3,3,18,7,2,color);c.round(3,14,18,7,2,color);c.circle(7,6.5,1,0xFF202637);c.circle(7,17.5,1,0xFF202637);}
            case "shield" -> {c.line(4,4,20,4,1.5,color);c.line(4,4,5,15,1.5,color);c.line(20,4,19,15,1.5,color);c.line(5,15,12,21,1.5,color);c.line(19,15,12,21,1.5,color);}
            case "tool" -> {c.line(6,20,18,6,2,color);c.line(10,4,21,11,2,color);}

            case "spark", "logo" -> {
                c.line(12,2,12,22,1.6,color);c.line(2,12,22,12,1.6,color);
                c.line(6,6,18,18,1.1,color);c.line(18,6,6,18,1.1,color);
                c.ring(12,12,5,1.2,color);
            }
            case "wave" -> {for(int k=0;k<3;k++)for(int i=0;i<20;i++){
                double yy=6+k*6;c.line(2+i,yy+Math.sin(i*.35)*2,3+i,yy+Math.sin((i+1)*.35)*2,1.4,color);}}
            case "grid" -> {for(int i=0;i<4;i++)c.round(3+(i%2)*11,3+(i/2)*11,7,7,2,color);}
            case "sliders" -> {for(int i=0;i<3;i++){c.line(3,5+i*7,21,5+i*7,1.2,color);c.circle(i==1?15:8,5+i*7,2.6,color);}}
            case "cursor" -> {c.line(5,3,8,20,1.5,color);c.line(5,3,19,13,1.5,color);c.line(19,13,12,14,1.5,color);c.line(12,14,8,20,1.5,color);}
            case "ring" -> c.ring(12,12,8,1.5,color);
            case "sun" -> {c.ring(12,12,4.5,1.5,color);for(int i=0;i<8;i++){double a=i*Math.PI/4;c.line(12+Math.cos(a)*8,12+Math.sin(a)*8,12+Math.cos(a)*10,12+Math.sin(a)*10,1.3,color);}}
            case "search" -> {c.ring(10,10,6,1.4,color);c.line(14.5,14.5,20,20,1.4,color);}
            case "close" -> {c.line(7,7,17,17,1.5,color);c.line(17,7,7,17,1.5,color);}
            case "check" -> {c.line(5,12,10,17,1.7,color);c.line(10,17,20,6,1.7,color);}
            case "info" -> {c.ring(12,12,9,1.3,color);c.circle(12,7,1,color);c.line(12,11,12,17,1.5,color);}
            case "pause" -> {c.round(6,4,4,16,1,color);c.round(14,4,4,16,1,color);}
            default -> {c.line(4,12,20,12,1.5,color);c.line(14,6,20,12,1.5,color);c.line(14,18,20,12,1.5,color);}
        }
        c.pop();
    }
}
