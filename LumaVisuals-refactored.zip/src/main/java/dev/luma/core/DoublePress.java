package dev.luma.core;
/** Confirmation only; never issues inventory actions or changes the selected item. */
public final class DoublePress {
    public static final long WINDOW_NANOS=500_000_000L;
    private long lastSerial=-1, armedAt;
    private boolean armed;
    public boolean attempt(long serial,long now,boolean sameTarget){
        if(serial<=lastSerial)return false;
        lastSerial=serial;
        if(armed&&sameTarget&&now-armedAt>=0&&now-armedAt<=WINDOW_NANOS){clear();return true;}
        armed=true;armedAt=now;return false;
    }
    public void clear(){armed=false;}
}
