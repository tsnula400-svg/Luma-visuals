package dev.luma.core;

/** Logical coordinates. Adapters own transforms and GPU/Java2D state. */
public interface Canvas {
    void push(double x,double y,double scale,double alpha);
    void pop();
    void clip(double x,double y,double width,double height);
    void unclip();
    void rect(double x,double y,double w,double h,int color);
    default void gradient(double x,double y,double w,double h,int first,int last,boolean vertical){for(int i=0;i<32;i++){int col=mix(first,last,i/31.0);if(vertical)rect(x,y+h*i/32,w,h/32+.1,col);else rect(x+w*i/32,y,w/32+.1,h,col);}}
    void round(double x,double y,double w,double h,double radius,int color);
    void line(double x1,double y1,double x2,double y2,double width,int color);
    void circle(double x,double y,double radius,int color);
    default void dot(double x,double y,double r,int color){rect(x-r,y-r,r*2,r*2,color);}
    void text(String text,double x,double y,double size,int color);
    double textWidth(String text,double size);
    default void ring(double x,double y,double r,double width,int color){
        int n=48;for(int i=0;i<n;i++){double a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;
            line(x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(b)*r,y+Math.sin(b)*r,width,color);}
    }
    default void glow(double x,double y,double r,int rgb,double strength){
        for(int i=16;i>=1;i--)circle(x,y,r*i/16,alpha(rgb,strength*(1-i/18.0)/8));
    }
    static int alpha(int rgb,double a){return ((int)Math.round(Settings.clamp(a,0,1)*255)<<24)|(rgb&0xFFFFFF);}
    static int mix(int a,int b,double t){
        t=Settings.clamp(t,0,1);int out=0;
        for(int s=0;s<=24;s+=8){int x=(a>>>s)&255,y=(b>>>s)&255;out|=((int)Math.round(x+(y-x)*t))<<s;}return out;
    }
}
