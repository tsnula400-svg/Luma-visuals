package dev.luma.core;
import java.util.Properties;
/** Render-only settings persisted in the existing Settings file. */
public final class ViewModelConfig {
 public boolean enabled;public int swingStyle,equipStyle;
 public final Pose main=new Pose(),off=new Pose();
 public static final String[] PRESETS={"Default","Compact","Large","Low","High","Custom"}, SWINGS={"Vanilla","Smooth","Fast","Wide","Compact","Custom","Off"}, EQUIPS={"Vanilla","Smooth","Fast","Off"};
 public double swingSpeed=1;public double swingStrength=1;public double swingRotation=1;public double positionInfluence=1;public double scaleInfluence=0;
 public static final class Pose {
 public double horizontal=0;public double vertical=0;public double distance=0;public double scale=1;public double tilt=0;public double yaw=0;public double pitch=0;
 public int preset;
 public void preset(int n){preset=Math.max(0,Math.min(5,n));if(preset==5)return;horizontal=vertical=distance=tilt=yaw=pitch=0;scale=1;switch(preset){case 1->{scale=.75;vertical=-.12;}case 2->scale=1.2;case 3->vertical=-.25;case 4->vertical=.2;default->{}}}
 public void validate(){horizontal=Settings.clamp(horizontal,-0.8,0.8);vertical=Settings.clamp(vertical,-0.8,0.8);distance=Settings.clamp(distance,-0.8,0.8);scale=Settings.clamp(scale,0.4,1.6);tilt=Settings.clamp(tilt,-90,90);yaw=Settings.clamp(yaw,-90,90);pitch=Settings.clamp(pitch,-90,90);preset=Math.max(0,Math.min(5,preset));}
 void load(Properties p,String k){horizontal=n(p,k+"horizontal",0);vertical=n(p,k+"vertical",0);distance=n(p,k+"distance",0);scale=n(p,k+"scale",1);tilt=n(p,k+"tilt",0);yaw=n(p,k+"yaw",0);pitch=n(p,k+"pitch",0);preset=(int)n(p,k+"preset",0);}
 void save(Properties p,String k){put(p,k+"horizontal",horizontal);put(p,k+"vertical",vertical);put(p,k+"distance",distance);put(p,k+"scale",scale);put(p,k+"tilt",tilt);put(p,k+"yaw",yaw);put(p,k+"pitch",pitch);put(p,k+"preset",preset);}
 }
 private static double n(Properties p,String k,double d){try{double v=Double.parseDouble(p.getProperty(k,""));return Double.isFinite(v)?v:d;}catch(NumberFormatException e){return d;}}
 private static void put(Properties p,String k,double v){p.setProperty(k,Double.toString(v));}
 public void validate(){main.validate();off.validate();swingStyle=Math.max(0,Math.min(6,swingStyle));equipStyle=Math.max(0,Math.min(3,equipStyle));swingSpeed=Settings.clamp(swingSpeed,0.5,2);swingStrength=Settings.clamp(swingStrength,0,1.5);swingRotation=Settings.clamp(swingRotation,0,1.5);positionInfluence=Settings.clamp(positionInfluence,0,1.5);scaleInfluence=Settings.clamp(scaleInfluence,0,0.15);}
 public void load(Properties p){enabled=Boolean.parseBoolean(p.getProperty("viewModel.enabled","false"));main.load(p,"viewModel.main.");off.load(p,"viewModel.off.");swingStyle=(int)n(p,"viewModel.swingStyle",0);equipStyle=(int)n(p,"viewModel.equipStyle",0);swingSpeed=n(p,"viewModel."+"swingSpeed",1);swingStrength=n(p,"viewModel."+"swingStrength",1);swingRotation=n(p,"viewModel."+"swingRotation",1);positionInfluence=n(p,"viewModel."+"positionInfluence",1);scaleInfluence=n(p,"viewModel."+"scaleInfluence",0);}
 public void save(Properties p){p.setProperty("viewModel.enabled",Boolean.toString(enabled));main.save(p,"viewModel.main.");off.save(p,"viewModel.off.");put(p,"viewModel.swingStyle",swingStyle);put(p,"viewModel.equipStyle",equipStyle);put(p,"viewModel."+"swingSpeed",swingSpeed);put(p,"viewModel."+"swingStrength",swingStrength);put(p,"viewModel."+"swingRotation",swingRotation);put(p,"viewModel."+"positionInfluence",positionInfluence);put(p,"viewModel."+"scaleInfluence",scaleInfluence);}
 /** Endpoint-preserving render time warp; does not change entity attack timers. */
 public double progress(double p){p=Settings.clamp(p,0,1);if(swingStyle==6)return 0;if(swingStyle==0)return p;double speed=swingStyle==2?1.7:swingStyle==5?swingSpeed:1,t=1-Math.pow(1-p,speed);return swingStyle==1?t*t*(3-2*t):t;}
 public double strength(){return switch(swingStyle){case 3->1.35;case 4->.5;case 5->swingStrength;case 6->0;default->1;};}
 public double equip(double p){p=Settings.clamp(p,0,1);return switch(equipStyle){case 1->p*p*(3-2*p);case 2->p*p*p;case 3->0;default->p;};}
}
