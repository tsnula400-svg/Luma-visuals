package dev.luma.core;
import java.util.*;
public final class ModuleRegistry {
    private final Map<String,VisualModule> modules=new LinkedHashMap<>();
    public void register(VisualModule m){if(modules.putIfAbsent(m.id(),m)!=null)throw new IllegalArgumentException("Duplicate module: "+m.id());}
    public Collection<VisualModule> all(){return Collections.unmodifiableCollection(modules.values());}
    public void tick(){for(VisualModule m:modules.values())if(m.enabled())m.tick();}
    public void disableAll(){for(VisualModule m:modules.values())m.setEnabled(false);}
}
