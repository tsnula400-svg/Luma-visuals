package dev.luma.core;
import java.util.*;
import java.util.function.*;
import static dev.luma.core.Canvas.*;
/** Separate HUD window. Same font, palette, rounded controls and physical-pixel scaling as Luma. */
public final class HudSettingsPanel {
    public final Settings settings;
    private record Hit(String id,double x,double y,double w,double h,Runnable action,DoubleConsumer slide){boolean contains(double px,double py){return px>=x&&px<x+w&&py>=y&&py<y+h;}}
    private final List<Hit> hits=new ArrayList<>();
    private double ox,oy,unit,w,h,scroll,maxScroll,open,dt,mx=-1000,my=-1000;
    private int lastWidth,lastHeight;
    private final SmoothScroll scrolling=new SmoothScroll();
    private final Map<String,Motion.Values> animations=new HashMap<>();
    private boolean closed,changed;
    private Hit drag;
    public HudSettingsPanel(Settings s){settings=s;}
    public boolean closed(){return closed&&open<.012;}
    public boolean isClosing(){return closed;}
    public double openness(){return open;}
    public boolean takeChanged(){boolean b=changed;changed=false;return b;}
    public void close(){closed=true;release();}
    public void render(Canvas c,int width,int height){render(c,width,height,-1000,-1000,.1);}
    public void render(Canvas c,int width,int height,double mouseX,double mouseY,double elapsed){
        dt=Motion.delta(elapsed);boolean animate=settings.animated();
        if(width!=lastWidth||height!=lastHeight){release();lastWidth=width;lastHeight=height;}
        open=Motion.approach(open,closed?0:1,closed?Motion.EXIT_RESPONSE:Motion.RESPONSE,dt,animate);
        double base=Math.max(.3,Math.min(1.5,Math.min((width-24)/680.0,(height-24)/400.0)));
        w=Math.min(860,(width-24)/base);h=Math.min(720,(height-24)/base);
        unit=base*Motion.panelScale(open);ox=(width-w*unit)/2;oy=(height-h*unit)/2+Motion.panelSlide(open)*base;
        mx=(mouseX-ox)/unit;my=(mouseY-oy)/unit;
        // Fixed content ends at y=880: clamp before rendering and hits, including after resize.
        maxScroll=Math.max(0,930-h);scrolling.bounds(maxScroll);scroll=scrolling.update(dt,settings.smoothScroll&&animate);
        int a=0xFF000000|settings.uiAccentColor();hits.clear();
        c.rect(0,0,width,height,alpha(0x070A13,.55*open));c.push(ox,oy,unit,open);
        c.round(-1,-1,w+2,h+2,17,alpha(a,.32));c.round(0,0,w,h,16,alpha(0x10121D,settings.opacity));
        c.text("HUD",24,18,28,0xFFF2F4FC);c.text("Орбита · две полоски. Капсулы · блоки. Минимал · текст.",24,57,16,0xFFADB0C4);
        button(c,"back","Назад",w-110,20,86,38,this::close,a);
        c.clip(20,98,w-40,h-146);c.push(0,-scroll,1,1);
        double y=106;
        toggle(c,"enabled","Показывать HUD",24,y,w-48,settings.hud.enabled,()->settings.hud.enabled=!settings.hud.enabled,a);y+=64;
        double cw=(w-64)/3;
        for(int i=0;i<3;i++){final int j=i;button(c,"style"+i,HudConfig.STYLES[i],24+i*(cw+8),y,cw,46,()->{settings.hud.style=j;settings.hud.resetPositions();},settings.hud.style==i?a:0xFF707A96);}
        y+=70;
        slider(c,"scale","Масштаб",24,y,w-48,(settings.hud.scale-.65)/.95,Math.round(settings.hud.scale*100)+"%",v->{settings.hud.scale=.65+.95*v;},a);y+=84;
        slider(c,"opacity","Непрозрачность фона",24,y,w-48,(settings.hud.opacity-.15)/.85,Math.round(settings.hud.opacity*100)+"%",v->settings.hud.opacity=.15+.85*v,a);y+=88;
        c.text("Элементы · каждый включается отдельно",24,y,19,0xFFF2F4FC);y+=38;
        double col=(w-56)/2;
        for(int i=0;i<HudConfig.IDS.length;i++){final int j=i;toggle(c,HudConfig.IDS[i],HudConfig.NAMES[i],24+(i%2)*(col+8),y+(i/2)*64,col,settings.hud.visible[i],()->{settings.hud.visible[j]=!settings.hud.visible[j];},a);}
        y+=5*64+8;button(c,"positions","Сбросить расположение",24,y,w-48,48,()->settings.hud.resetPositions(),a);y+=64;
        c.text("Чат: перетаскивай HUD. В Орбите перемещается вся полоска.",24,y,15,0xFFADB0C4);y+=38;
        c.pop();c.unclip();
        if(maxScroll>0){double vh=h-146,th=Math.max(24,vh*vh/(vh+maxScroll));c.round(w-12,98,3,vh,1,alpha(a,.12));c.round(w-12,98+(vh-th)*scroll/maxScroll,3,th,1,a);}
        c.text("Позиции и настройки сохраняются на этом устройстве",24,h-31,15,0xFFADB0C4);c.pop();
    }
    private double anim(String id,int channel,double target){
        Motion.Values state=animations.get(id);if(state==null){state=new Motion.Values();animations.put(id,state);}
        return state.to(channel,target,dt,settings.animated(),channel==0?0:target);
    }
    private boolean over(String id,double x,double y,double w,double h){
        if(closed||!settings.hover)return false;boolean fixed=id.equals("back");if(!fixed&&(my<98||my>=this.h-48))return false;
        double py=my+(fixed?0:scroll);return mx>=x&&mx<x+w&&py>=y&&py<y+h;
    }
    private void button(Canvas c,String id,String title,double x,double y,double w,double h,Runnable run,int a){
        double hv=anim(id,0,over(id,x,y,w,h)?1:0);c.round(x,y,w,h,9,alpha(a,.13+hv*.09));c.line(x+10,y+1,x+w-10,y+1,1,alpha(a,.08+hv*.18));
        c.text(HudLayout.fit(c,title,w-24,17),x+12,y+(h-22)/2,17,0xFFF2F4FC);hits.add(new Hit(id,x,y,w,h,run,null));
    }
    private void toggle(Canvas c,String id,String title,double x,double y,double w,boolean value,Runnable run,int a){
        double on=anim(id,1,value?1:0),hv=anim(id,0,over(id,x,y,w,54)?1:0);
        c.round(x,y,w,54,9,alpha(a,.04+on*.07+hv*.05));c.text(HudLayout.fit(c,title,w-66,16),x+12,y+15,16,0xFFF2F4FC);
        c.round(x+w-47,y+17,34,20,10,mix(0xFF343849,a,on));c.circle(x+w-37+14*on,y+27,6,0xFFF2F4FC);hits.add(new Hit(id,x,y,w,54,run,null));
    }
    private void slider(Canvas c,String id,String title,double x,double y,double w,double v,String text,DoubleConsumer setter,int a){
        double hv=anim(id,0,over(id,x,y+26,w,38)||drag!=null&&drag.id.equals(id)?1:0);
        c.text(title,x,y,18,0xFFF2F4FC);c.text(text,x+w-c.textWidth(text,17),y,17,a);c.round(x,y+43,w,5,2,0xFF343849);c.round(x,y+43,Math.max(4,w*v),5,2,a);c.circle(x+w*v,y+45,10+hv*2,alpha(a,.12+hv*.1));c.circle(x+w*v,y+45,7+hv*.5,0xFFF2F4FC);hits.add(new Hit(id,x,y+26,w,38,()->{},setter));
    }
    public boolean click(double px,double py,int button){if(button!=0||closed||open<.2)return false;double x=(px-ox)/unit,y=(py-oy)/unit;
        for(int i=hits.size()-1;i>=0;i--){Hit hit=hits.get(i);boolean fixed=hit.id.equals("back");if(!fixed&&(y<98||y>=h-48))continue;double yy=y+(fixed?0:scroll);if(hit.contains(x,yy)){if(!fixed)scrolling.jump(scroll);if(hit.slide!=null){drag=hit;move(px,py);}else hit.action.run();changed=true;return true;}}return false;}
    public void move(double px,double py){if(!closed&&drag!=null){drag.slide.accept(Settings.clamp(((px-ox)/unit-drag.x)/drag.w,0,1));changed=true;}}
    public void release(){drag=null;}
    public void scroll(double amount){if(closed||drag!=null||!Double.isFinite(amount))return;scrolling.move(-amount*48,settings.smoothScroll&&settings.animated());scroll=scrolling.value();}
    public void reveal(String id){for(Hit hit:hits)if(hit.id.equals(id)&&!id.equals("back")){scrolling.jump(hit.y-106);scroll=scrolling.value();}}
    public double[] center(String id){for(Hit hit:hits)if(hit.id.equals(id))return new double[]{ox+(hit.x+hit.w/2)*unit,oy+(hit.y+hit.h/2-(id.equals("back")?0:scroll))*unit};throw new IllegalArgumentException(id);}
}
