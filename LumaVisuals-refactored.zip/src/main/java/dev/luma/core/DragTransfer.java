package dev.luma.core;

import java.util.HashSet;
import java.util.Set;
/** One attempt per source slot per held gesture. No queued clicks after release. */
public final class DragTransfer {
    private final Set<Integer> visited=new HashSet<>();
    private boolean active;
    private Object source;
    public void begin(Object inventory){visited.clear();source=inventory;active=true;}
    public boolean active(){return active;}
    public boolean visit(int slot,Object inventory){return active&&slot>=0&&source==inventory&&visited.add(slot);}
    public void end(){active=false;source=null;visited.clear();}
}
