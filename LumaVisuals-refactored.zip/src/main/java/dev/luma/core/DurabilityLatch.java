package dev.luma.core;
import java.util.*;
/** Per equipped slot hysteresis; warn once until repaired, replaced or unequipped. */
public final class DurabilityLatch {
    private final Map<String,Entry> entries=new HashMap<>();
    private record Entry(Object identity,boolean warned){}
    public boolean update(String slot,Object identity,int remaining,int maximum,int threshold){
        if(identity==null||maximum<=0){entries.remove(slot);return false;}
        Entry e=entries.get(slot);
        boolean warned=e!=null&&Objects.equals(e.identity,identity)&&e.warned;
        double pct=100.0*remaining/maximum;
        if(pct>threshold+5)warned=false;
        boolean notify=pct<=threshold&&!warned;
        entries.put(slot,new Entry(identity,warned||notify));return notify;
    }
    public void clear(){entries.clear();}
}
