package dev.luma.preview;
import dev.luma.core.*;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.List;
import javax.imageio.ImageIO;
/** Synthetic frames of real shared UI code; no game, GL or Fabric API doubles. */
public final class AnimationChecks {
    private static int n;
    private static void check(boolean ok,String text){n++;if(!ok)throw new AssertionError(text);}
    private static void near(double a,double b,String text){check(Math.abs(a-b)<.001,text);}
    private static final class Probe implements Canvas {
        int stack,clips;
        private void finite(double... values){for(double v:values)if(!Double.isFinite(v))throw new AssertionError("non-finite render geometry");}
        public void push(double x,double y,double s,double a){finite(x,y,s,a);if(s<=0||a<0||a>1)throw new AssertionError("invalid transform");stack++;}
        public void pop(){if(--stack<0)throw new AssertionError("stack underflow");}
        public void clip(double x,double y,double w,double h){finite(x,y,w,h);if(w<0||h<0)throw new AssertionError("invalid clip");clips++;}
        public void unclip(){if(--clips<0)throw new AssertionError("clip underflow");}
        public void rect(double x,double y,double w,double h,int c){finite(x,y,w,h);}
        public void round(double x,double y,double w,double h,double radius,int c){finite(x,y,w,h,radius);}
        public void circle(double x,double y,double radius,int c){finite(x,y,radius);}
        public void line(double x,double y,double a,double b,double w,int c){finite(x,y,a,b,w);}
        public void text(String text,double x,double y,double size,int c){finite(x,y,size);}
        public double textWidth(String text,double size){return UiFont.width(text,size);}
        void balanced(){check(stack==0&&clips==0,"balanced render scopes");}
    }
    private static void frame(Menu m,Probe p,int w,int h,double dt){m.render(p,w,h,-1000,-1000,dt);p.balanced();}
    private static void settle(Menu m,Probe p,int w,int h){for(int i=0;i<70;i++)frame(m,p,w,h,1.0/60);}
    private static HudLayout.Data data(){return new HudLayout.Data(new String[]{"LumaPlayer","144 FPS","38 ms","X -435  Y 72  Z -50","4.3 б/с","Мой сервер","18 онлайн"},List.of(new HudLayout.Equipment("head","Шлем",100,true),new HudLayout.Equipment("chest","Нагрудник",82,true)),List.of(new HudLayout.Equipment("main","Кирка",24,true)));}
    private static void bounds(HudLayout h,int w,int height){
        List<HudLayout.Box> boxes=h.boxes();
        for(var b:boxes)check(b.x()>=0&&b.y()>=0&&b.x()+b.w()<=w+.001&&b.y()+b.h()<=height+.001,"HUD animated bounds");
        for(int i=0;i<boxes.size();i++)for(int j=i+1;j<boxes.size();j++){var a=boxes.get(i);var b=boxes.get(j);check(a.x()+a.w()<=b.x()+.001||b.x()+b.w()<=a.x()+.001||a.y()+a.h()<=b.y()+.001||b.y()+b.h()<=a.y()+.001,"HUD animated default cards do not overlap");}
        for(var icon:h.icons())check(boxes.stream().anyMatch(b->icon.x()>=b.x()-.001&&icon.y()>=b.y()-.001&&icon.x()+icon.size()<=b.x()+b.w()+.001&&icon.y()+icon.size()<=b.y()+b.h()+.001),"item bounds match animated card");
    }
    public static void run()throws Exception{
        n=0;Probe p=new Probe();double target=Motion.damp(0,1,18,.1);
        for(int fps:new int[]{30,60,120}){double value=0;for(int i=0;i<fps/10;i++)value=Motion.damp(value,1,18,1.0/fps);near(value,target,"framerate invariant damping");}
        near(Motion.delta(Double.NaN),0,"NaN delta");near(Motion.delta(-1),0,"negative delta");near(Motion.delta(12),.1,"long pause bounded");near(Motion.approach(.2,1,18,0,false),1,"reduced motion instant");
        check(Motion.stagger(.08,0,true)>Motion.stagger(.08,3,true),"stagger order");near(Motion.stagger(0,4,false),1,"reduced stagger");
        for(int[] size:new int[][]{{640,360},{1280,720},{1920,1080}}){
            int w=size[0],h=size[1];Settings s=new Settings();s.background=false;Menu m=new Menu(s);frame(m,p,w,h,1.0/120);
            double[] xy=m.controlCenter("motion");check(!m.click(xy[0],xy[1],0),"invisible opening menu not interactive");
            double prev=m.openness();for(int i=0;i<30;i++){frame(m,p,w,h,1.0/60);check(m.openness()>=prev&&m.openness()<=1,"monotonic open");prev=m.openness();}
            xy=m.controlCenter("motion");double[] nav=m.controlCenter("nav4");check(m.click(nav[0],nav[1],0)&&m.tab()==4,"navigation queues selected tab");check(!m.click(xy[0],xy[1],0)&&s.motion,"old hits invalidated");
            prev=m.transitionOpacity();frame(m,p,w,h,1.0/60);check(m.transitionOpacity()>0&&m.transitionOpacity()<prev,"outgoing content fades");check(!m.click(xy[0],xy[1],0)&&s.motion,"outgoing controls inert");
            m.setTab(2);m.setTab(6);settle(m,p,w,h);check(m.tab()==6&&!m.transitioning(),"rapid navigation uses latest target");
            m.revealControl("customSkinEnabled");frame(m,p,w,h,1.0/60);xy=m.controlCenter("customSkinEnabled");check(m.click(xy[0],xy[1],0)&&s.customSkinEnabled,"incoming slide hit transform");m.release();
            m.setTab(4);settle(m,p,w,h);m.revealControl("scale");frame(m,p,w,h,1.0/60);xy=m.controlCenter("scale");check(m.click(xy[0],xy[1],0),"begin scale drag");double v=s.scale;
            frame(m,p,w+100,h+70,1.0/60);m.move(10000,10000);near(s.scale,v,"resize cancels stale drag");
            prev=m.openness();m.requestClose();frame(m,p,w,h,1.0/60);check(m.openness()>0&&m.openness()<prev,"smooth close reversal");v=s.scale;m.key(48,true,false);m.move(0,0);near(s.scale,v,"close blocks keyboard and drag");settle(m,p,w,h);check(m.closed(),"bounded close");
            s.reduced=true;m=new Menu(s);frame(m,p,w,h,0);near(m.openness(),1,"reduced open");m.requestClose();frame(m,p,w,h,0);check(m.closed(),"reduced close");s.reduced=false;
            HudSettingsPanel panel=new HudSettingsPanel(s);panel.render(p,w,h,0,0,.06);check(panel.openness()>0&&panel.openness()<1,"panel entry intermediate");panel.reveal("scale");panel.render(p,w,h,0,0,.05);xy=panel.center("scale");check(panel.click(xy[0],xy[1],0),"panel animated hit");v=s.hud.scale;
            panel.close();panel.move(10000,0);panel.scroll(-2);near(s.hud.scale,v,"panel closing blocks drag");check(panel.isClosing()&&!panel.closed(),"wait for panel exit");for(int i=0;i<45;i++)panel.render(p,w,h,0,0,1.0/60);check(panel.closed(),"panel exit completes");xy=panel.center("enabled");check(!panel.click(xy[0],xy[1],0),"closed panel rejects click");p.balanced();
            for(int style=0;style<3;style++){
                HudConfig cfg=new HudConfig();cfg.style=style;HudLayout hud=new HudLayout(cfg);var d=data();prev=0;
                for(int i=0;i<45;i++){hud.render(p,w,h,d,0xFFA599FF,false,1.0/60,true);p.balanced();check(hud.visibility(0)>=prev,"HUD monotonic appearance");prev=hud.visibility(0);bounds(hud,w,h);}
                cfg.visible[1]=false;prev=hud.visibility(1);hud.render(p,w,h,d,0xFFA599FF,false,1.0/60,true);check(hud.visibility(1)>0&&hud.visibility(1)<prev,"HUD disappearance intermediate");for(int i=0;i<45;i++){hud.render(p,w,h,d,0xFFA599FF,false,1.0/60,true);bounds(hud,w,h);}
                check(hud.boxes().stream().noneMatch(b->b.id()==1),"hidden HUD card removed");var box=hud.boxes().get(0);check(!hud.click(box.x()+2,box.y()+2,false),"HUD not interactive outside editor");
                hud.render(p,w,h,d,0xFFA599FF,true,1.0/60,true);box=hud.boxes().get(0);check(hud.click(box.x()+2,box.y()+2,false),"editor hit stable");hud.move(box.x()+12,box.y()+12);hud.render(p,w,h,d,0xFFA599FF,true,1.0/60,true);check(hud.dragging()&&hud.takeChanged(),"HUD animation does not restart drag");hud.stop();
                cfg.enabled=false;hud.render(p,w,h,d,0xFFA599FF,false,0,false);check(hud.boxes().isEmpty()&&hud.icons().isEmpty(),"motion disabled hides instantly");hud.resetAnimation();check(hud.visibility(0)==0&&!hud.dragging(),"world reset clears animation");
            }
        }
        Settings s=new Settings();s.background=false;Menu m=new Menu(s);settle(m,p,1280,720);
        var f=Menu.class.getDeclaredField("animations");f.setAccessible(true);var map=(java.util.Map<?,?>)f.get(m);Object state=map.get("motion");int count=map.size();double[] xy=m.controlCenter("motion");for(int i=0;i<240;i++)m.render(p,1280,720,i%2==0?xy[0]:-1000,xy[1],1.0/60);
        check(map.size()==count&&map.get("motion")==state,"animation channels reused after warmup");check(!m.takeChanged(),"animation does not dirty config");p.balanced();
        System.out.println("PASS: "+n+" animation/input/geometry assertions; synthetic real-core frames, NOT Minecraft/GL/FPS verification.");
    }
    private static void capture(Menu m,HudSettingsPanel panel,HudLayout hud,int w,int h,double mx,double my,double dt,Path file)throws Exception{
        BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();g.setPaint(new GradientPaint(0,0,new Color(0x263345),w,h,new Color(0x14202B)));g.fillRect(0,0,w,h);
        try(Java2DCanvas c=new Java2DCanvas(g,Preview.font())){if(m!=null)m.render(c,w,h,mx,my,dt);if(panel!=null)panel.render(c,w,h,mx,my,dt);if(hud!=null){hud.render(c,w,h,data(),0xFFA599FF,false,dt,true);for(var icon:hud.icons()){double z=icon.size();c.round(icon.x(),icon.y(),z,z,3,0xFF728299);c.line(icon.x()+z*.25,icon.y()+z*.75,icon.x()+z*.75,icon.y()+z*.25,Math.max(.1,z/9),0xFFE2EBF8);}}}finally{g.dispose();}
        if(hud!=null)image=image.getSubimage(0,0,w,180);ImageIO.write(image,"png",file.toFile());
    }
    public static void main(String[] args)throws Exception{
        run();if(args.length==0)return;Path out=Path.of(args[0]);Files.createDirectories(out);Probe p=new Probe();Settings s=new Settings();s.background=false;Menu m=new Menu(s);
        frame(m,p,1280,720,.025);capture(m,null,null,1280,720,-1000,-1000,.025,out.resolve("01-menu-opening.png"));settle(m,p,1280,720);double[] xy=m.controlCenter("motion");for(int i=0;i<20;i++)m.render(p,1280,720,xy[0],xy[1],1.0/60);capture(m,null,null,1280,720,xy[0],xy[1],1.0/60,out.resolve("02-menu-hover.png"));
        double[] nav=m.controlCenter("nav4");m.click(nav[0],nav[1],0);capture(m,null,null,1280,720,-1000,-1000,.035,out.resolve("03-tab-outgoing.png"));for(int i=0;i<10;i++)frame(m,p,1280,720,1.0/60);capture(m,null,null,1280,720,-1000,-1000,.035,out.resolve("04-tab-incoming.png"));settle(m,p,1280,720);m.requestClose();capture(m,null,null,1280,720,-1000,-1000,.05,out.resolve("05-menu-closing.png"));
        HudSettingsPanel panel=new HudSettingsPanel(s);for(int i=0;i<60;i++)panel.render(p,1280,720,0,0,1.0/60);xy=panel.center("enabled");panel.click(xy[0],xy[1],0);for(int i=0;i<5;i++)panel.render(p,1280,720,xy[0],xy[1],1.0/60);capture(null,panel,null,1280,720,xy[0],xy[1],1.0/60,out.resolve("06-hud-panel-hover.png"));panel.reveal("armor");capture(null,panel,null,640,360,-1000,-1000,.1,out.resolve("07-hud-panel-small.png"));
        HudConfig cfg=new HudConfig();cfg.style=1;HudLayout hud=new HudLayout(cfg);for(int i=0;i<60;i++)hud.render(p,1280,720,data(),0xFFA599FF,false,1.0/60,true);cfg.visible[1]=false;capture(null,null,hud,1280,720,-1000,-1000,.035,out.resolve("08-hud-card-exit.png"));
        Files.writeString(out.resolve("PROVENANCE.txt"),"Actual shared UI code rendered offline via Java2D. Not Minecraft screenshots. HUD crop uses original 1280x720 layout; neutral item markers are software preview placeholders. No game/OpenGL execution.\n");
    }
}
