package dev.luma.preview;
import dev.luma.core.*;
import java.nio.file.*;
public final class ToolSafetyChecks {
    private static int n;
    private static void check(boolean value,String message){n++;if(!value)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        check(ToolSafetyRules.effectiveThreshold(1561,100)==100,"diamond: 100 points");
        check(ToolSafetyRules.effectiveThreshold(59,100)==5,"wood: 5 points, never fresh tool");
        check(ToolSafetyRules.effectiveThreshold(32,100)==3,"gold: 3 points");
        check(ToolSafetyRules.effectiveThreshold(250,100)==25,"iron: cap to low durability");
        check(!ToolSafetyRules.needsStash(true,101,1561,100),"above threshold stays");
        check(ToolSafetyRules.needsStash(true,100,1561,100),"at threshold stashes");
        check(!ToolSafetyRules.needsStash(false,1,432,100),"unsupported/wearable never stashes");
        check(!ToolSafetyRules.needsStash(true,59,59,100),"fresh wood stays");
        check(!ToolSafetyRules.needsStash(true,0,0,100),"non damageable stays");
        boolean[] empty=new boolean[41];empty[0]=empty[36]=empty[40]=true;
        check(ToolSafetyRules.emptyMainSlot(empty)==-1,"never hotbar, armor, offhand");
        empty[35]=true;check(ToolSafetyRules.emptyMainSlot(empty)==35,"last inventory slot accepted");
        empty[9]=true;check(ToolSafetyRules.emptyMainSlot(empty)==9,"first empty main inventory slot");
        check(ToolSafetyRules.emptyMainSlot(null)==-1,"invalid inventory safe");
        for(int max=2;max<2500;max++){
            int t=ToolSafetyRules.effectiveThreshold(max,100);
            check(t>0&&t<max&&t<=100,"bounded threshold");
            check(!ToolSafetyRules.needsStash(true,max,max,100),"no fresh tool is moved");
        }
        Path path=Files.createTempFile("luma-tool-safety-",".properties");
        try{
            Settings s=new Settings();check(!s.toolSafety,"opt in by default");s.toolSafety=true;s.toolSafetyThreshold=50;s.save(path);
            Settings loaded=Settings.load(path);check(loaded.toolSafety&&loaded.toolSafetyThreshold==50,"saved preferences");
            loaded.reset();check(loaded.toolSafety&&loaded.toolSafetyThreshold==50,"appearance reset preserves safety");
            Files.writeString(path,"theme=2\n");loaded=Settings.load(path);check(!loaded.toolSafety&&loaded.toolSafetyThreshold==100,"old config migration");
        }finally{Files.deleteIfExists(path);}
        System.out.println("PASS: "+n+" tool safety rule/settings checks. Not a Minecraft integration test.");
    }
}
