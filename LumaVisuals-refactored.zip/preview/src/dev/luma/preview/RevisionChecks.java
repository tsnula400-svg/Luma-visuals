package dev.luma.preview;
import dev.luma.core.*;
import java.nio.file.*;
import java.util.*;
public final class RevisionChecks {
    private static int n;
    private static void check(boolean ok,String text){n++;if(!ok)throw new AssertionError(text);}
    private static void draw(Menu m,int w,int h,Path file)throws Exception{MenuChecks.render(m,Preview.font(),w,h,file);}
    private static void click(Menu m,String id,int w,int h)throws Exception{m.revealControl(id);draw(m,w,h,null);double[] xy=m.controlCenter(id);check(m.click(xy[0],xy[1],0),"click "+id);m.release();}
    public static void main(String[] args)throws Exception{
        Path out=Path.of(args.length>0?args[0]:"preview/images");Files.createDirectories(out);
        Properties old=new Properties();old.setProperty("hud.placed","true");old.setProperty("hud.style","2");old.setProperty("hud.nick.x",".99");old.setProperty("hud.fps.visible","false");
        HudConfig migrated=new HudConfig();migrated.load(old);check(!migrated.placed&&migrated.style==0&&!migrated.visible[1],"old layout resets once, visibility retained");
        migrated.style=1;migrated.placed=true;migrated.x[0]=.75;migrated.groupX[0]=.3;Properties saved=new Properties();migrated.save(saved);HudConfig restored=new HudConfig();restored.load(saved);check(restored.placed&&restored.style==1&&restored.x[0]==.75&&restored.groupX[0]==.3,"v2 layout persists without reset");
        for(int[] size:new int[][]{{640,360},{1280,720},{2000,900}})for(boolean animation:new boolean[]{false,true}){
            int w=size[0],h=size[1];Settings s=new Settings();s.background=false;s.motion=animation;Menu m=new Menu(s);m.setTab(2);
            for(int i=0;i<20;i++)draw(m,w,h,null);
            check(!m.controlIds().contains("toolSafetyThreshold"),"threshold not in general list");
            click(m,"toolSafetySettings",w,h);check(!s.toolSafety,"settings button does not toggle module");
            if(animation){draw(m,w,h,null);check(!m.controlIds().contains("toolSafetyThreshold"),"partially revealed slider not clickable");}
            for(int i=0;i<80;i++)draw(m,w,h,null);
            check(m.controlIds().contains("toolSafetyThreshold"),"slider exists after open");
            click(m,"toolSafetyThreshold",w,h);check(s.toolSafetyThreshold>=99&&s.toolSafetyThreshold<=101,"slider applies value");
            click(m,"toolSafety",w,h);check(s.toolSafety,"separate toggle works");
            click(m,"toolSafetySettings",w,h);draw(m,w,h,null);check(!m.controlIds().contains("toolSafetyThreshold"),"closing settings cannot intercept input");
            for(int i=0;i<80;i++)draw(m,w,h,null);
            check(s.toolSafety,"collapse leaves module enabled");
        }
        Settings s=new Settings();s.reduced=true;s.background=false;Menu m=new Menu(s);m.setTab(2);draw(m,1280,900,null);m.revealControl("toolSafetySettings");draw(m,1280,900,out.resolve("module-closed.png"));
        click(m,"toolSafetySettings",1280,900);draw(m,1280,900,null);m.revealControl("toolSafetySettings");draw(m,1280,900,out.resolve("module-open.png"));
        draw(m,640,360,null);m.revealControl("toolSafetySettings");draw(m,640,360,out.resolve("module-open-small.png"));
        // Collapse then capture an animated mid-frame from the same layout engine.
        click(m,"toolSafetySettings",640,360);draw(m,1280,900,null);s.reduced=false;s.motion=true;click(m,"toolSafetySettings",1280,900);draw(m,1280,900,out.resolve("module-opening.png"));
        System.out.println("PASS: "+n+" migration/module/animation checks. Software core only, no Minecraft/GL execution.");
    }
}
