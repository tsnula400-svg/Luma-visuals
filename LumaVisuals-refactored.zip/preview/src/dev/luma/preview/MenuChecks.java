package dev.luma.preview;

import dev.luma.core.Menu;
import dev.luma.core.Settings;
import dev.luma.core.HudSettingsPanel;
import javax.imageio.ImageIO;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;

/** Deterministic checks against actual shared layout/hit regions. No Minecraft dependencies. */
public final class MenuChecks {
    private static int checks;
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static void render(Menu m,Font f,int w,int h,Path dest)throws Exception{
        BufferedImage image=new BufferedImage(dest==null?1:w,dest==null?1:h,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=image.createGraphics();Preview.backdrop(g,w,h);
        try(Java2DCanvas c=new Java2DCanvas(g,f)){m.render(c,w,h,-1000,-1000,.1);}finally{g.dispose();}
        if(dest!=null)ImageIO.write(image,"png",dest.toFile());
    }
    static void click(Menu m,String id){double[] p=m.controlCenter(id);check(m.click(p[0],p[1],0),"click "+id);m.release();}
    /** Exercise real event handlers, including events between rendered frames. */
    private static void inputLifecycleChecks()throws Exception{
        var failures=new java.util.ArrayList<String>();
        Font f=Preview.font();
        Settings s=new Settings();s.motion=false;s.background=false;
        Menu m=new Menu(s);m.setTab(4);render(m,f,1280,720,null);
        m.revealControl("scale");render(m,f,1280,720,null);
        double[] point=m.controlCenter("scale");m.click(point[0],point[1],0);
        double before=s.scale;m.requestClose();m.move(10000,point[1]);
        if(s.scale!=before)failures.add("closing menu still accepts slider drag");
        s.scale=1.25;m.key(48,true,false);
        if(s.scale!=1.25)failures.add("closing menu still accepts keyboard changes");
        s=new Settings();s.motion=false;s.background=false;m=new Menu(s);render(m,f,1280,720,null);
        point=m.controlCenter("motion");m.setTab(4);m.click(point[0],point[1],0);
        if(s.motion)failures.add("previous tab hit regions remain interactive before redraw");
        s=new Settings();s.background=false;m=new Menu(s);
        BufferedImage image=new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=image.createGraphics();
        try(Java2DCanvas c=new Java2DCanvas(g,f)){
            m.render(c,1280,720,-1000,-1000,Double.NaN);
            m.render(c,1280,720,-1000,-1000,.1);
            point=m.controlCenter("motion");
            if(!Double.isFinite(point[0])||!Double.isFinite(point[1]))failures.add("invalid frame delta poisons future menu transforms");
        }catch(IllegalArgumentException ex){failures.add("invalid frame delta breaks rendering: "+ex.getMessage());}
        finally{g.dispose();}
        s=new Settings();HudSettingsPanel panel=new HudSettingsPanel(s);
        g=image.createGraphics();
        try(Java2DCanvas c=new Java2DCanvas(g,f)){panel.render(c,1280,720);}finally{g.dispose();}
        point=panel.center("scale");panel.click(point[0],point[1],0);before=s.hud.scale;
        panel.close();panel.move(10000,point[1]);
        if(s.hud.scale!=before)failures.add("closed HUD settings still accepts slider drag");
        boolean enabled=s.hud.enabled;point=panel.center("enabled");panel.click(point[0],point[1],0);
        if(s.hud.enabled!=enabled)failures.add("closed HUD settings still accepts clicks");
        if(!failures.isEmpty())throw new AssertionError(String.join("; ",failures));
        System.out.println("PASS: 6 input lifecycle regressions; real Java core, not Minecraft.");
    }
    public static void main(String[] args)throws Exception{
        inputLifecycleChecks();
        if(args.length>0&&args[0].equals("--input-regression"))return;
        AnimationChecks.run();VisualRenderingChecks.run();
        Font f=Preview.font();Path out=Path.of(args.length>0?args[0]:"preview/images");Files.createDirectories(out);
        int[][] windows={{640,360},{800,600},{1280,720},{1920,1080},{2560,1440},{3840,2160}};
        for(int[] wh:windows)for(double scale:new double[]{.85,1,1.25,1.75}){
            int w=wh[0],h=wh[1];Settings s=new Settings();s.motion=false;s.background=false;s.scale=scale;Menu m=new Menu(s);
            render(m,f,w,h,null);check(m.scrollLimit()>0,"scrollable options");
            click(m,"motion");check(s.motion,"toggle hit matches rendered position");s.motion=false;
            m.revealControl("reduced");render(m,f,w,h,null);click(m,"reduced");check(s.reduced,"last option reachable");
            click(m,"nav4");render(m,f,w,h,null);check(m.tab()==4,"settings tab");
            click(m,"theme3");check(s.theme==3,"theme");
            m.revealControl("scale");render(m,f,w,h,null);
            double[] p=m.controlCenter("scale");m.click(p[0],p[1],0);m.move(-10000,p[1]);m.release();check(s.scale==Settings.MIN_SCALE,"scale lower clamp");
            render(m,f,w,h,null);m.revealControl("scale");render(m,f,w,h,null);p=m.controlCenter("scale");m.click(p[0],p[1],0);m.move(10000,p[1]);m.release();check(s.scale==Settings.MAX_SCALE,"scale upper clamp");
            render(m,f,w,h,null);m.key(48,true,false);check(s.scale==1,"Ctrl+0");
            render(m,f,w,h,null);m.revealControl("reset");render(m,f,w,h,null);click(m,"reset");check(s.theme==0&&s.scale==1,"reset");s.motion=false;
            click(m,"nav0");render(m,f,w,h,null);m.key(70,true,false);for(char c:"иконки".toCharArray())m.character(c);render(m,f,w,h,null);
            check(m.controlIds().contains("proximity")&&!m.controlIds().contains("motion"),"search filter");
            for(char c:"неттакого".toCharArray())m.character(c);render(m,f,w,h,null);check(!m.controlIds().contains("proximity"),"empty search");
            m.setTab(1);render(m,f,w,h,null);m.key(267,false,false);check(m.scrollOffset()>0,"PageDown");m.key(266,false,false);check(m.scrollOffset()==0,"PageUp");
            for(int i=0;i<20;i++){m.key(258,false,false);render(m,f,w,h,null);}check(m.scrollOffset()>=0&&m.scrollOffset()<=m.scrollLimit(),"keyboard reveal clamped");
            // Changing dimensions preserves valid viewport/hit transforms.
            render(m,f,800,600,null);click(m,"nav3");check(m.tab()==3,"resize hit mapping");
        }
        Settings s=new Settings();s.motion=false;s.background=false;Menu m=new Menu(s);
        render(m,f,1280,720,null);double first=m.effectiveScale();s.scale=1.25;render(m,f,1280,720,null);check(m.effectiveScale()>first*1.2,"125 percent actually grows instead of fixed panel fit");
        Path config=Files.createTempFile("luma-check-",".properties");
        try{
            Files.writeString(config,"format=1\nscale=1.25\ntheme=4\nbackground=false\n");Settings old=Settings.load(config);
            check(old.scale==1.25&&old.theme==4&&!old.background,"0.1.0 settings preserved");
            old.scale=1.75;old.save(config);check(Settings.load(config).scale==1.75,"new maximum persists");
            Files.writeString(config,"scale=NaN\nspeed=Infinity\nopacity=0\ntheme=999\n");Settings bad=Settings.load(config);check(bad.scale==1&&bad.speed==1&&bad.opacity==.82&&bad.theme==5,"invalid settings validated");
        }finally{Files.deleteIfExists(config);}
        // Additional visual states, all produced by the real Menu.java.
        for(int tab=2;tab<=4;tab++){
            Settings v=new Settings();v.reduced=true;v.theme=tab==4?3:0;Menu vm=new Menu(v);vm.setTab(tab);
            render(vm,f,1280,720,out.resolve("0"+(tab+2)+"-tab-"+tab+".png"));
            vm.key(267,false,false);render(vm,f,1280,720,out.resolve("0"+(tab+5)+"-tab-"+tab+"-scrolled.png"));
        }
        Settings v=new Settings();v.reduced=true;v.background=false;v.scale=1.75;Menu vm=new Menu(v);vm.setTab(4);
        render(vm,f,640,360,out.resolve("10-small-settings.png"));vm.revealControl("reset");render(vm,f,640,360,out.resolve("11-small-reset.png"));
        vm.setTab(0);render(vm,f,800,600,null);vm.key(70,true,false);for(char c:"нетрезультатов".toCharArray())vm.character(c);
        render(vm,f,800,600,out.resolve("12-empty-search.png"));
        System.out.println("PASS: "+checks+" assertions; 24 window/scale combinations; shared Java core only, NOT a Fabric build.");
    }
}
