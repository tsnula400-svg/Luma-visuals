#!/usr/bin/env python3
"""Deterministic source geometry + UV atlas. Requires Python 3 and Pillow.
Run from any directory; outputs only the custom-skin model and its textures.
The JSON is an offline inspection export, NOT a Minecraft replacement renderer.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import random, json, math
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'src/main/resources/assets/luma/textures/entity'
TOOLS=Path(__file__).parent
MATERIALS=[('hood',(28,27,36)),('purple',(58,39,68)),('teal',(22,63,60)),('bone',(185,185,161)),('socket',(10,14,16)),('boneShade',(119,127,111)),('steel',(70,88,78)),('grip',(16,26,24)),('wrap',(42,80,46)),('trim',(88,59,98)),('core',(172,255,117)),('energy',(47,195,48)),('halo',(9,43,12)),('cloth',(35,31,45)),('streak',(211,255,171)),('seam',(43,40,53))]
# Dedicated weapon materials occupy unused lower-right quarters of existing tiles.
WEAPON=[('silver',(166,184,205)),('gold',(192,143,69)),('violetwrap',(104,61,118)),('obsidian',(27,29,43))]
MATERIALS+=WEAPON
parts=[]
def part(name,parent=None,pivot=(0,0,0),rot=(0,0,0),layer='main'):
    p=dict(name=name,parent=parent,pivot=list(pivot),rot=list(rot),layer=layer,boxes=[]);parts.append(p);return p

def box(p,mat,x,y,z,w,h,d):
    idx=[m[0] for m in MATERIALS].index(mat)
    n=len(p['boxes'])
    tile=idx if idx<16 else idx-16+6
    u=(tile%4)*64+(5 if idx<16 else 36)+(n%3)*6
    v=(tile//4)*64+(5 if idx<16 else 36)+(n%2)*7
    assert w>0 and h>0 and d>0
    assert u+2*w+2*d<(tile%4+1)*64 and v+h+d<(tile//4+1)*64
    p['boxes'].append(dict(mat=mat,xyz=[x,y,z],size=[w,h,d],uv=[u,v]))

# Sculpted hood: open front, stepped crown, cowl, separate hanging folds.
p=part('hood')
box(p,'hood',-4.25,-8.0,-4.05,8.5,8.1,8.5)
# Recessed backing hides the vanilla head; sculpted bones project well in front.
box(p,'hood',-3.55,-8.85,-3.75,7.1,.85,7.9)
box(p,'purple',-2.4,-9.15,-3.45,4.8,.3,7.0)
for s in (-1,1):
    x=-4.7 if s<0 else 3.75
    box(p,'hood',x,-7.35,-4.5,.95,7.5,8.6)
    box(p,'purple',-4.25 if s<0 else 3.6,-7.3,-4.8,.65,5.85,.65)
    box(p,'seam',-3.8 if s<0 else 3.25,-6.85,-5.0,.55,4.65,.35)
    box(p,'hood',-3.9 if s<0 else 2.6,-1.9,-4.65,1.3,2.5,1.8)
    box(p,'teal',-3.45 if s<0 else 2.7,-1.1,-4.9,.75,1.55,.35)
# Stepped fabric folds around the rear and side of the hood (not armor plates).
for s in (-1,1):
    for i in range(3):
        box(p,'purple' if i==1 else 'seam',-4.84 if s<0 else 4.7,-6.2+i*.8,-2.8+i*1.6,.14,5.6-i*.8,.7)
for i in range(3):
    box(p,'seam',-2.75+i*2.05,-7.15,4.46,.55,6.1-i*.4,.19)
# Crown/forehead tapers down into separate temple blocks.
box(p,'boneShade',-2.75,-7.0,-4.6,5.5,1.25,.65)
box(p,'bone',-2.05,-7.45,-4.9,4.1,1.1,.75)
box(p,'bone',-2.9,-6.6,-5.34,5.8,.9,1.05)
box(p,'bone',-.43,-5.85,-5.40,.86,1.58,1.08)
for s in (-1,1):
    x=-2.55 if s<0 else .7
    box(p,'socket',x,-5.75,-4.7,1.85,1.9,.5)
    box(p,'bone',-3.15 if s<0 else 2.6,-5.7,-5.24,.55,2.05,1.05)
    box(p,'boneShade',-2.8 if s<0 else 1.0,-3.95,-5.22,1.8,.65,1.05)
    box(p,'bone',-3.1 if s<0 else 1.95,-3.65,-5.55,1.15,.85,1.28)
    box(p,'boneShade',-2.05 if s<0 else 1.2,-2.9,-5.08,.85,1.35,.87)
# Nose aperture deliberately black, flanked by bone, not a luminous green face.
box(p,'socket',-.45,-3.95,-5.16,.9,1.25,.35)
box(p,'bone',-1.2,-3.15,-5.15,.7,1.05,.75)
box(p,'bone',.5,-3.15,-5.15,.7,1.05,.75)
box(p,'boneShade',-1.85,-1.08,-5.18,3.7,.68,1.02)
for i in range(5):
    box(p,'bone',-1.65+i*.69,-2.22,-5.22,.46,1.12 if i%2==0 else .98,.8)
box(p,'hood',-2.1,-.35,-4.25,4.2,.75,1.1)

# Anatomical LEFT is +X in the player model (viewer's right in a front view).
# Dominant left eye and deliberately smaller/dimmer right eye, in separate render roots.
p=part('eyes',layer='glow')
# An 8-pixel radial iris is baked large then scaled locally to 1.36 model pixels.
# This preserves a real soft texture gradient instead of sub-pixel UV squares.
iris=part('left_iris','eyes',(1.62,-4.65,-4.90),layer='glow')
box(iris,'energy',-4,-4,-1,8,8,1)
iris['boxes'][0]['uv']=[224,224]
part('right_eye',layer='glow')
iris=part('right_iris','right_eye',(-1.62,-4.65,-4.90),layer='glow')
box(iris,'energy',-4,-4,-1,8,8,1)
iris['boxes'][0]['uv']=[224,224]

# Open rib cage: collarbones, sternum, curved individual ribs and vertebrae.
p=part('ribs')
box(p,'socket',-3.6,.15,-2.18,7.2,10.6,.25)
box(p,'boneShade',-.65,-.25,-2.72,1.3,1.0,.65)
for s in (-1,1):
    for i in range(2):
        box(p,'bone',(-2.9+i*1.25) if s<0 else (.4+i*1.25),.2+i*.35,-2.98,1.5,.55,.75)
box(p,'bone',-.4,1.3,-3.1,.8,6.25,.85)
for row,extent in enumerate((3.0,3.2,2.9,2.55,2.1)):
    y=1.8+row*1.5
    for s in (-1,1):
        length=(extent-.42)/2
        rib=part('rib_%d_%s'%(row,'r' if s<0 else 'l'),'ribs',(s*.42,y+.38,-3.22),(0,0,-s*.13))
        box(rib,'bone',-2*length if s<0 else 0,0,0,length*2,.49,.87)
        box(rib,'boneShade',-2*length if s<0 else 2*length-.40,-.20,.18,.40,.58,.86)
        box(p,'boneShade',-extent-.2 if s<0 else extent-.48,y-.13,-2.95,.68,.84,1.25)
        box(p,'boneShade',-extent-.2 if s<0 else extent-.53,y-.3,-1.88,.73,.52,1.2)
for i in range(3):box(p,'boneShade',-.5,8.0+i*.82,-2.69,1,.55,.5)
# Narrow opening lapels, waist belt and teal inner tabard.
for s in (-1,1):
    box(p,'purple',-4.2 if s<0 else 3.45,.0,-2.65,.75,10.7,1.0)
    box(p,'trim',-3.64 if s<0 else 3.35,1.1,-2.9,.28,8.8,.55)
box(p,'grip',-4.12,10.6,-2.4,8.24,1.2,4.8)
box(p,'steel',-.9,10.67,-2.7,1.8,.9,.45)
box(p,'wrap',-.55,10.89,-2.96,1.1,.4,.25)

# Back yoke stays on body; free panels start at the waist rather than neck.
p=part('cloak')
box(p,'hood',-4.4,.15,2.15,8.8,9.7,.65)
box(p,'purple',-3.7,.45,2.8,7.4,4.7,.55)
box(p,'purple',-2.6,4.8,2.82,5.2,1.6,.5)
box(p,'trim',-.65,1.2,3.39,1.3,5.9,.2)
for s in (-1,1):
    box(p,'teal',-3.9 if s<0 else 2.5,5.0,2.88,1.4,4.2,.42)
for name,s in [('cloak_left',-1),('cloak_right',1)]:
    p=part(name,'cloak',(s*2.15,9.6,2.9))
    box(p,'purple',-2.16,0,0,4.32,8.3,.65)
    box(p,'hood',-1.35,.4,.67,2.5,9.0,.35)
    box(p,'teal',-.75,3.1,.99,1.5,5.4,.23)
    for i,h in enumerate((2.4,1.1,3.1,1.8) if s<0 else (1.4,2.8,.7,2.1)):
        box(p,'purple',-2.16+i*1.08,8.3,0,1.08,h,.65)
    box(p,'trim',-1.95,.25,-.08,.22,8.55,.18)
    # Nested folds inherit the original waist animation, no additional simulation.
    q=part(name+'_outer',name,(s*1.76,.4,.15),(0,s*.24,-s*.09))
    box(q,'hood',-.56,0,0,1.12,8.9,.40)
    box(q,'purple',-.56,8.9,0,.48,1.45,.40)
    box(q,'teal',.05,2.4,-.12,.42,6.9,.20)
    q=part(name+'_inner',name,(-s*.78,1.6,.83),(0,-s*.18,s*.07))
    box(q,'purple',-.62,0,0,1.24,7.9,.24)
    box(q,'hood',-.62,7.9,0,.49,1.2,.24)
# Shoulders and sleeves are arm-local, no body-fixed armor slabs.
for name,s in [('right',-1),('left',1)]:
    x0=-3.0 if s<0 else -1.0
    p=part('sleeve_'+name)
    box(p,'purple',x0-.18,-1.8,-2.24,4.36,3.0,4.48)
    box(p,'trim',x0+.25,-2.28,-1.7,3.5,.48,3.4)
    box(p,'hood',x0-.05,1.2,-2.13,4.1,5.6,4.26)
    box(p,'purple',x0-.2,4.4,-2.32,4.4,2.3,.42)
    box(p,'teal',x0+.8,3.25,-2.33,1.5,1.8,.3)
    for i,h in enumerate((1.6,.7,1.1)):
        box(p,'purple',x0+i*1.42,6.7,-2.32,1.42,h,.42)
    box(p,'boneShade',x0+.2,8.2,-2.12,3.6,.75,4.24)
    for i in range(3):box(p,'bone',x0+.5+i*.94,9,-2.19,.58,.85,.25)
    # A separate short cloth flap at the arm's outer edge.
    q=part('shoulder_'+name,'sleeve_'+name,(x0 if s<0 else x0+4,-.6,0))
    box(q,'purple',-.32,0,-2.4,.64,4.4,4.8)
    box(q,'teal',-.36,2.6,-1.3,.72,2.9,2.6)
    box(q,'purple',-.4,3.6,-.7,.8,2.8,1.4)
# Split skirt follows each leg: front, outer side, rear. No box around both legs.
for name,s in [('right',-1),('left',1)]:
    p=part('leg_'+name)
    box(p,'hood',-2.1,-.25,-2.2,4.2,8.7,4.4)
    box(p,'teal',-1.78,.1,-2.48,3.56,6.9,.35)
    box(p,'purple',-2.25,-.25,-2.77,.8,8.6,.55)
    box(p,'purple',1.45,-.25,-2.77,.8,7.5,.55)
    box(p,'trim',-2.04,.15,-2.94,.25,7.8,.18)
    for i,h in enumerate((1.3,2.5,1.7)):
        box(p,'teal',-1.78+i*1.186,7,-2.48,1.186,h,.35)
    box(p,'purple',-2.28 if s<0 else 1.92,.1,-1.85,.36,8.5,3.7)
    for i,h in enumerate((1.5,2.7,1.1)):
        box(p,'purple',-2.28 if s<0 else 1.92,8.6,-1.85+i*1.23,.36,h,1.23)
    box(p,'hood',-2.1,9.1,-2.25,4.2,2.9,4.5)
    box(p,'purple',-2.15,10.5,-2.32,4.3,.85,4.64)

# Curved stepped blade, shared path for opaque steel, emissive core and moving glint.
# Body-local diagonal back mount. Positive Z is behind the torso.
# Minimum guard Z=4.75, behind the hood/back-yoke; blade stays outside cloth.
MOUNT=(4.4,-3.0,5.8); ANGLE=(0,0,.58)
p=part('katana');g=part('katana_grip','katana',MOUNT,ANGLE)
# Two visible leather retainers join the weapon to the yoke; NOT separate entities.
for y in (4.0,9.2):
    box(g,'grip',-.73,y,-2.45,1.46,.48,2.10)
    box(g,'steel',-.73,y,.27,1.46,.48,.18)
box(g,'obsidian',-.48,-2.1,-.43,.96,4.25,.86)
for i in range(6):
    box(g,'violetwrap',-.53,-1.85+i*.61,-.49,1.06,.23,.98)
    # Inlaid brass diamonds on BOTH faces: rear view is the requested view.
    for z in (-.54,.44):
        box(g,'gold',-.15,-1.56+i*.61,z,.30,.22,.10)
box(g,'gold',-.64,-2.45,-.58,1.28,.45,1.16)
box(g,'violetwrap',-.4,-2.64,-.42,.8,.19,.84)
box(g,'obsidian',-1.55,2.05,-1.05,3.1,.4,2.1)
box(g,'gold',-1.23,1.96,-.78,2.46,.16,1.56)
box(g,'gold',-.61,2.4,-.4,1.22,.65,.8)
# Small brass guard tips remain readable without tinting the whole blade.
for x in (-1.55,1.25):box(g,'gold',x,2.03,-1.06,.30,.44,2.12)
# Smoothly curved, increasingly tapered 18-section blade. Rotated local sections
# follow the tangent instead of six unrotated stairs. Root mount/handle unchanged.
# Each section has a dark spine, cool steel face and separate polished cutting edge.
segments=[]
def blade_center(y):
    t=max(0,min(1,(y-3.0)/13.0));return -1.35*t*t

def blade_width(y):
    t=max(0,min(1,(y-3.0)/13.0))
    return .93*(1-.22*t)*(max(.025,(1-t)/.20) if t>.80 else 1)

part('blade_glow',layer='glow');part('blade_energy','blade_glow',MOUNT,ANGLE,'glow')
for i in range(18):
    y=3+13*i/18;h=13/18;mid=y+h/2;x=blade_center(mid);w=blade_width(mid)
    tangent=math.atan(2*1.35*((mid-3)/13)/13)
    thickness=.32*(1-.70*((mid-3)/13)**3)
    segments.append((y,h,x,w))
    section=part('blade_section_'+str(i),'katana_grip',(x,mid,0),(0,0,tangent))
    # Opaque steel silhouette, with intentionally separated surface details.
    box(section,'silver',-w/2,-h/2,-thickness/2,w,h+.04,thickness)
    box(section,'obsidian',w*.36,-h/2,-thickness*.42,w*.14,h+.04,thickness*.84)
    # Bright bevel and hamon: dedicated neutral-metal swatch, not green/gold paint.
    for z in (-thickness/2-.018,thickness/2+.003):
        box(section,'silver',-w/2,-h/2,z,w*.24,h+.035,.015)
        section['boxes'][-1]['uv']=[184,113]
        box(section,'silver',-w*.24+math.sin(i*.85)*w*.035,-h/2,z,w*.055,h+.025,.015)
        section['boxes'][-1]['uv']=[184,122]
    energy=part('edge_section_'+str(i),'blade_energy',(x,mid,0),(0,0,tangent),'glow')
    for z in (-thickness/2-.04,thickness/2+.025):
        box(energy,'energy',-w/2,-h/2,z,w*.085,h+.028,.012)
# Fine pointed kissaki cap. The final slice is narrow and substantially thinner.
p=part('blade_tip','katana_grip',(-1.35,16,0),(0,0,.20))
box(p,'silver',-.012,-.04,-.024,.024,.09,.048)
p=part('blade_streak',layer='glow');q=part('streak_grip','blade_streak',MOUNT,ANGLE,'glow');r=part('glint','streak_grip',layer='glow')
box(r,'streak',-.30,-.40,-.23,.60,.80,.025)
box(r,'streak',-.30,-.40,.205,.60,.80,.025)
p=part('sparks',layer='glow');q=part('sparks_grip','sparks',MOUNT,ANGLE,'glow')
for i in range(5):
    r=part('spark_'+str(i),'sparks_grip',layer='glow');sz=.16+(i%3)*.055
    box(r,'energy',-sz/2,-sz/2,-sz/2,sz,sz,sz)

# Code is kept inside the existing class. No extra game classes or loader changes.
def f(v):
    s=f'{v:.5f}'.rstrip('0').rstrip('.');return (s if '.' in s else s+'.0')+'f'
lines=['package dev.luma.client.skin;','','import net.minecraft.client.model.ModelData;','import net.minecraft.client.model.ModelPartBuilder;','import net.minecraft.client.model.ModelPartData;','import net.minecraft.client.model.ModelTransform;','import net.minecraft.client.model.TexturedModelData;','','/** Refined sculpted skull, left eye, articulated cloth and back-mounted katana.',' * Generated by tools/custom_skin_v2/generate.py; vanilla animation roots are retained. */','public final class CustomSkinModel {','    public static TexturedModelData getTexturedModelData() {','        ModelData data = new ModelData();','        ModelPartData root = data.getRoot();']
for p in parts:
    parent=p['parent'] or 'root'
    lines.append(f'        ModelPartData {p["name"]} = {parent}.addChild("{p["name"]}", ModelPartBuilder.create()')
    for b in p['boxes']:
        u,v=b['uv'];lines.append(f'            .uv({u}, {v}).cuboid('+', '.join(f(n) for n in b['xyz']+b['size'])+')')
    transform='ModelTransform.NONE' if not any(p['pivot']+p['rot']) else 'ModelTransform.of('+', '.join(f(n) for n in p['pivot']+p['rot'])+')'
    lines.append('            , '+transform+');')
lines+=['        return TexturedModelData.of(data, 256, 256);','    }','}']
(ROOT/'src/main/java/dev/luma/client/skin/CustomSkinModel.java').write_text('\n'.join(lines)+'\n')
TOOLS.mkdir(parents=True,exist_ok=True)
(TOOLS/'geometry.json').write_text(json.dumps(dict(materials=MATERIALS,parts=parts,segments=segments),indent=2)+'\n')

# UV tiles: controlled mottling, vertical fabric folds, warm weathered bone.
rng=random.Random(1502);atlas=Image.new('RGBA',(256,256));glow=Image.new('RGBA',(256,256),(0,0,0,255))
for idx,(name,col) in enumerate(MATERIALS[:16]):
    ox=idx%4*64;oy=idx//4*64
    for y in range(64):
        for x in range(64):
            n=rng.choice([-7,-3,0,0,2,5])
            if name in ('purple','hood','cloth','teal','trim','seam'):
                n+=int(9*math.sin((x//2)*1.17)+4*math.sin((x//3)*.65+(y//3)*.37))
                if (x//2+3*(y//3))%17==0:n-=9
                if x%13==0:n-=5
            elif name in ('bone','boneShade'):n+=(-12 if (x//2+y//3)%11==0 else 0)
            elif name in ('core','energy','halo','streak'):n=0
            c=tuple(max(0,min(255,k+n)) for k in col)+(255,)
            atlas.putpixel((ox+x,oy+y),c)
            if name in ('core','energy','halo','streak'):glow.putpixel((ox+x,oy+y),c)
# Independent weapon swatches: never recolor the existing clothes or belt.
for idx,(name,col) in enumerate(WEAPON):
    tile=idx+6;ox=tile%4*64+32;oy=tile//4*64+32
    for yy in range(32):
        for xx in range(32):
            n=((-5,0,4,8)[(xx//2+yy//3)%4] if name!='silver' else (-8,2,16,5)[(xx//2)%4])
            atlas.putpixel((ox+xx,oy+yy),tuple(max(0,min(255,c+n)) for c in col)+(255,))
# Dedicated neutral steel bevel / hamon swatches; isolated from clothing UVs.
for yy in range(112,128):
    for xx in range(182,192):
        col=(225,237,248,255) if yy<120 else (145,171,196,255)
        atlas.putpixel((xx,yy),col)
# Isolated eye UV patch: front is [225,225..233,233], back [234..242].
# Black additive pixels add no light. Includes no opaque/main eye texture.
for x0 in (225,234):
    for yy in range(8):
        for xx in range(8):
            radius=math.sqrt(((xx-3.5)/3.6)**2+((yy-3.5)/3.4)**2)
            fall=max(0.0,1.0-radius)**1.15
            core=max(0.0,1.0-radius*1.7)
            rgb=(min(255,int(90*fall+210*core)),min(255,int(255*fall+100*core)),min(255,int(115*fall+180*core)),255)
            glow.putpixel((x0+xx,225+yy),rgb)
atlas.save(OUT/'custom_skin_parts.png');glow.save(OUT/'custom_skin_glow.png')
# Vanilla under-suit, deliberately recessed and dark under the real skull/ribs.
# Full base layer supports first-person hands; outer layers stay transparent.
skin=Image.new('RGBA',(64,64),(0,0,0,0));sd=ImageDraw.Draw(skin)
def area(rect,col):
    for y in range(rect[1],rect[3]):
        for x in range(rect[0],rect[2]):
            n=rng.choice([-3,0,0,3]);skin.putpixel((x,y),tuple(max(0,min(255,c+n)) for c in col)+(255,))
area((0,0,32,16),(25,24,32))
area((16,16,40,32),(27,26,33))
area((0,16,16,32),(29,32,35));area((16,48,32,64),(29,32,35))
area((40,16,56,32),(55,36,65));area((32,48,48,64),(55,36,65))
for rect in [(40,28,56,32),(32,60,48,64)]:area(rect,(135,145,124))
# Visible wrist bones and seams in first person, correct modern 64x64 skin layout.
for x,y in [(44,20),(36,52)]:
    sd.rectangle((x,y+3,x+3,y+4),fill=(23,61,55,255))
    sd.line((x,y,x,y+7),fill=(84,56,92,255))
    for dx in (0,2):sd.line((x+dx,y+9,x+dx,y+11),fill=(179,184,156,255))
skin.save(OUT/'custom_skin.png')
print(f'Generated {len(parts)} parts, {sum(len(p["boxes"]) for p in parts)} cuboids; 256x256 atlases; 64x64 under-suit.')
