#!/usr/bin/env python3
"""Placeholder textures for Luma custom skin (skull + hood + mantle + katana)."""
from PIL import Image

def fill(img, x, y, w, h, color):
    for px in range(x, x + w):
        for py in range(y, y + h):
            if 0 <= px < img.width and 0 <= py < img.height:
                img.putpixel((px, py), color)

def draw_rect(img, x, y, w, h, color):
    fill(img, x, y, w, h, color)

# --- 64x64 skin texture ---
skin = Image.new("RGBA", (64, 64), (0, 0, 0, 0))

# Colors
dark = (22, 18, 34, 255)
hood = (44, 34, 72, 255)
hood2 = (60, 48, 96, 255)
robe = (30, 26, 48, 255)
robe2 = (48, 42, 74, 255)
teal = (30, 120, 120, 255)
bone = (200, 205, 210, 255)
eye_glow = (60, 255, 80, 255)

# Head front 8x8 at (8,8)
draw_rect(skin, 8, 8, 8, 8, hood)
fill(skin, 10, 10, 4, 4, bone)
fill(skin, 11, 11, 1, 1, (0, 0, 0, 255))
fill(skin, 13, 11, 1, 1, eye_glow)
fill(skin, 11, 14, 2, 1, (0, 0, 0, 255))
# Head sides/top/back
fill(skin, 0, 8, 8, 8, hood)
fill(skin, 16, 8, 8, 8, hood)
fill(skin, 24, 8, 8, 8, hood)
fill(skin, 8, 0, 8, 8, hood)
fill(skin, 16, 0, 8, 8, hood)
# Hat outer layer front (40,8)
fill(skin, 40, 8, 8, 8, hood2)
fill(skin, 40, 0, 8, 8, hood2)
fill(skin, 32, 8, 8, 8, hood2)
fill(skin, 48, 8, 8, 8, hood2)
fill(skin, 56, 8, 8, 8, hood2)

# Body front (20,20)
fill(skin, 20, 20, 8, 12, robe)
fill(skin, 22, 22, 4, 4, bone)
fill(skin, 22, 28, 4, 1, bone)
# Body back/sides
fill(skin, 28, 20, 4, 12, robe2)
fill(skin, 32, 20, 8, 12, robe)
fill(skin, 16, 20, 4, 12, robe2)
fill(skin, 52, 20, 4, 12, robe2)
fill(skin, 56, 20, 8, 12, robe)
fill(skin, 44, 16, 4, 4, robe2)

# Arms
fill(skin, 44, 20, 4, 12, robe2)
fill(skin, 48, 20, 4, 12, robe)
fill(skin, 44, 36, 4, 12, robe2)
fill(skin, 48, 36, 4, 12, robe)
fill(skin, 40, 52, 4, 12, robe2)
fill(skin, 44, 52, 4, 12, robe)
fill(skin, 40, 36, 4, 12, robe2)
fill(skin, 36, 52, 4, 12, robe)

# Legs
fill(skin, 4, 20, 4, 12, robe)
fill(skin, 8, 20, 4, 12, robe2)
fill(skin, 20, 52, 4, 12, robe)
fill(skin, 24, 52, 4, 12, robe2)
fill(skin, 0, 20, 4, 12, robe2)
fill(skin, 12, 20, 4, 12, robe)
fill(skin, 16, 52, 4, 12, robe2)
fill(skin, 28, 52, 4, 12, robe)

# Add some teal accents
for y in [20, 24, 28, 32]:
    fill(skin, 20, y, 8, 1, teal)

skin.save("/data/project/LumaVisuals/src/main/resources/assets/luma/textures/entity/custom_skin.png")

# --- 128x128 parts texture ---
parts = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
# Hood box (0,0) 9x9x9 -> 6 faces, but just fill a block
draw_rect(parts, 0, 0, 36, 18, hood)
fill(parts, 2, 2, 32, 14, hood2)
# Ribs (36,0)
fill(parts, 36, 0, 14, 10, bone)
fill(parts, 38, 2, 10, 6, (160, 165, 170, 255))
# Cloak (0,36)
fill(parts, 0, 36, 18, 24, robe)
fill(parts, 32, 36, 18, 28, robe2)
fill(parts, 50, 36, 18, 26, robe)
# Add tattered edges
tear = (0, 0, 0, 0)
for i in range(0, 18, 3):
    fill(parts, i, 56, 2, 4, tear)
    fill(parts, 32+i, 60, 2, 4, tear)
# Katana (64,0)
fill(parts, 64, 0, 8, 28, (0, 0, 0, 255))  # handle/guard
fill(parts, 66, 4, 4, 24, (40, 40, 40, 255))
fill(parts, 65, 8, 6, 18, (60, 255, 80, 255)) # blade core
# Eyes/streak (0,96)
fill(parts, 0, 96, 4, 2, eye_glow)
fill(parts, 8, 96, 6, 10, (120, 255, 140, 255))
fill(parts, 16, 96, 4, 4, (200, 255, 210, 255))

parts.save("/data/project/LumaVisuals/src/main/resources/assets/luma/textures/entity/custom_skin_parts.png")

# --- 128x128 glow texture (additive) ---
glow = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
# Eyes (0,96) in UV
fill(glow, 0, 96, 4, 2, (60, 255, 80, 255))
# Streak (8,96)
fill(glow, 8, 96, 6, 10, (150, 255, 170, 255))
fill(glow, 9, 98, 4, 6, (255, 255, 255, 255))

glow.save("/data/project/LumaVisuals/src/main/resources/assets/luma/textures/entity/custom_skin_glow.png")

print("Custom skin textures generated.")
