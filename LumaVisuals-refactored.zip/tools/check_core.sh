#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
output="${1:-build/audit-core}"
mkdir -p "$output/classes"
mapfile -d '' sources < <(find src/main/java/dev/luma/core preview/src -name '*.java' -print0)
java -m jdk.compiler/com.sun.tools.javac.Main --release 21 -encoding UTF-8 -d "$output/classes" "${sources[@]}"
cp -R src/main/resources/assets "$output/classes/"
python3 tools/validate_mobilefix.py
for check in MenuChecks RenderBudgetChecks UtilityChecks ToolSafetyChecks NewFeatureChecks RevisionChecks CustomSkinChecks AuditChecks; do
  echo "=== $check ==="
  java -Xmx512m -Djava.awt.headless=true -cp "$output/classes" "dev.luma.preview.$check"
done
java tools/SyntaxCheck.java
