#!/usr/bin/env python3
"""Offline normalization regressions, not a Fabric or in-game test."""
import unittest
from verify_jar import normalize_javap

A = '''class Probe {
  public java.lang.String value(boolean);
    descriptor: (Z)Ljava/lang/String;
    Code:
         0: iload_1
         1: ifeq          7
         4: ldc           #9                  // String hi  #123
         6: areturn
         7: ldc           #10                 // String no
         9: areturn
}'''
B = '''class Probe {
  public java.lang.String value(boolean);
    descriptor: (Z)Ljava/lang/String;
    Code:
         0: iload_1
         1: ifeq          8
         4: ldc_w         #300                // String hi  #123
         7: areturn
         8: ldc_w         #301                // String no
        11: areturn
}'''
class NormalizationTests(unittest.TestCase):
    def test_pool_padding_width_and_branches(self):
        self.assertEqual(normalize_javap(A), normalize_javap(B))
    def test_string_whitespace_not_ignored(self):
        self.assertNotEqual(normalize_javap(A), normalize_javap(A.replace('hi  #123','hi #123')))
    def test_hash_digits_in_string_not_ignored(self):
        self.assertNotEqual(normalize_javap(A), normalize_javap(A.replace('hi  #123','hi  #124')))
    def test_changed_branch_rejected(self):
        self.assertNotEqual(normalize_javap(A), normalize_javap(A.replace('ifeq          7','ifeq          6')))
    def test_changed_opcode_rejected(self):
        self.assertNotEqual(normalize_javap(A), normalize_javap(A.replace('ifeq','ifne')))
    def test_changed_method_rejected(self):
        self.assertNotEqual(normalize_javap(A), normalize_javap(A.replace('value(boolean)','other(boolean)')))
    def test_switch_targets(self):
        a='    Code:\n 0: ldc #2 // String a\n 2: lookupswitch { // 1\n  1: 20\n  default: 20\n }\n 20: return'
        b='    Code:\n 0: ldc_w #300 // String a\n 3: lookupswitch { // 1\n  1: 24\n  default: 24\n }\n 24: return'
        self.assertEqual(normalize_javap(a), normalize_javap(b))
        self.assertNotEqual(normalize_javap(a), normalize_javap(b.replace('1: 24','2: 24')))
    def test_handlers(self):
        a='    Code:\n 0: ldc #2 // String a\n 2: areturn\n 3: athrow\n Exception table:\n from to target type\n 0 3 3 any'
        b='    Code:\n 0: ldc_w #300 // String a\n 3: areturn\n 4: athrow\n Exception table:\n from to target type\n 0 4 4 any'
        self.assertEqual(normalize_javap(a), normalize_javap(b))
    def test_goto_width(self):
        self.assertEqual(normalize_javap('    Code:\n 0: goto 3\n 3: return'), normalize_javap('    Code:\n 0: goto_w 5\n 5: return'))

if __name__ == '__main__': unittest.main(verbosity=2)
