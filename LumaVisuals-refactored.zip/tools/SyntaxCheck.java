import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;
/** Syntax parsing only, NOT dependency resolution/type checking or Fabric build. */
public class SyntaxCheck {
 public static void main(String[] args)throws Exception{
  var compiler=ToolProvider.getSystemJavaCompiler();var diagnostics=new DiagnosticCollector<JavaFileObject>();
  try(var manager=compiler.getStandardFileManager(diagnostics,Locale.ROOT,java.nio.charset.StandardCharsets.UTF_8);var paths=Files.walk(Path.of("src/main/java"))){
   var files=paths.filter(p->p.toString().endsWith(".java")).map(Path::toFile).toList();
   JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("--release","21","-proc:none"),null,manager.getJavaFileObjectsFromFiles(files));task.parse();
   for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
   System.out.println("PASS: syntax parsed "+files.size()+" Java files. NOT Minecraft type-checking/Mixin validation.");
  }
 }
}
