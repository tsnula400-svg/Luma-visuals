# LUME VISUALS — visual/rendering update, Alpha 0.1.5

## Статус и границы результата

Это обновление исходников предоставленного архива, не переписывание проекта и не опубликованный GitHub commit. Mod ID `luma`, пакеты, имена ресурсов, имя config и версия 0.1.5 сохранены для совместимости. Готового игрового JAR в поставке нет.

- STATIC VERIFICATION: общий Java core/preview компилируется с `--release 21`; старые и новые исполняемые проверки проходят.
- SHADER SURROGATE: GLSL ES 300 через WebGL2/ANGLE/SwiftShader, чтение реальных пикселей RGBA8 — PASS. В тесте изменена только директива `#version 150` на `#version 300 es`.
- FABRIC BUILD: NOT RUN. Gradle отсутствует; загрузка зависимостей недоступна в рабочей среде. Minecraft-зависимые классы и Mixin remapping НЕ компилировались.
- IN-GAME VERIFICATION: NOT RUN. Minecraft, Zalith Launcher 2 и Android/MobileGlues не запускались.
- Следовательно, полная готовность к игровому тесту не объявляется до успешного существующего CI build. Успех desktop/софтверного GLSL ES теста не доказывает совместимость с MobileGlues.

## Изученная архитектура

`core/Menu` + `Canvas` — общее меню для MinecraftCanvas и Java2DCanvas; Settings — единственный properties config с validate/atomic save. HUD имеет общий HudLayout и отдельный игровой адаптер. Motion и SmoothScroll сохраняют прежнюю механику ограничения delta времени и освобождения drag/hit regions. Существующие игровые модули управляются Settings; пустой ModuleRegistry не стал вторым источником состояния.

WorldColor: color-copy FBO, fullscreen triangle, вызов после renderWorld и до GUI. WorldResolution завершает свой color pass внутри существующего wrap renderWorld. Custom Skin и его Python/Java2D offline previews не являются встроенным first-person 3D preview. Поэтому новый View Model использует настоящие руки в мире через боковую панель, а не дублирующий игровой renderer.

## Changed / Fixed

### Saturation: весь путь

`Menu.saturation` (0..1 slider) → `Settings.saturation = value*1.5` → тот же config, validate 0..1.5 → WorldColor runtime clamp → `LumeSaturation` uniform → shader → distinct copy framebuffer → основной framebuffer, до GUI.

- Старое ограничение 25% удалено в UI, config и shader.
- Старая HSV/chroma формула сохраняла максимум RGB; заменена на цветность относительно display-referred Rec.709 luma: `(0.2126,0.7152,0.0722)`.
- Ограничение усиления вдоль вектора цветности сохраняет luma и hue в доступном gamut; полностью насыщенный пиксель не может стать ещё насыщеннее без клиппинга. Это не дополнительная экспозиция/контраст и не физическая linear-light luminance.
- 0% → grayscale; 50% → уменьшенная цветность; 100% → идентичный исходник (в игре pass обходится); 150% → усиление до границы gamut.
- Движение slider включает эффект, uniform обновляется перед draw. Имя uniform не пересекается с общими штатными uniform.
- Явно связан Sampler0. После blit и draw проверяются GL errors. Диагностическое сообщение выводится при смене значения, а не на каждом кадре. Оно означает «pass submitted», не автоматическое доказательство итогового изображения на устройстве.
- FBO переиспользуется, пересоздаётся при resize, освобождается при отключении/выходе; source и copy не совпадают; depth не копируется.
- Восстанавливаются read/draw framebuffer, viewport, scissor, blend/depth/cull enable flags, depth mask, color mask, texture unit 0 binding, active texture и GL program. Blend factors не меняются данным pass.
- ShaderProgram получается через штатный ShaderLoader; stale program не кешируется между reload. Copy framebuffer не содержит ресурсов resource pack. Проверка F3+T на устройстве обязательна.
- В GLSL добавлены условные `highp float/int` для GL_ES/MG_MOBILEGLUES. Не добавлены SSBO/compute/HDR/desktop-only texture formats. Сохраняется штатный RGBA8 путь. Нестандартные sRGB/HDR FBO альтернативных renderer не поддерживаются; существующий запрет Iris/Vulkan/Optifabric/Canvas оставлен.

Причина слабого эффекта именно на устройстве пользователя не подтверждена запуском на нём. Исправлены обнаруженные ограничения и формула, но final Minecraft output и порядок с другими модами ещё требуют проверки.

### Защита инструментов

Существующий `toolSafetyThreshold` уже был реальным: default 100, диапазон 1..200, эффективный порог ограничен 10% максимальной прочности. Логика stash и сохранение не продублированы. В существующий visual notice добавлены эффективный порог и оставшаяся прочность. Отдельный процентный `durabilityThreshold` для предупреждений брони/предметов сохранён отдельно. Новая игровая автоматизация не добавлялась: прежние Auto Sprint, перенос предметов и ToolSafety не переписывались.

## Added

### Меню

- LV / LUME VISUALS branding, тонкие контуры и верхние грани cards, разделитель header.
- Стиль анимации: Smooth, Fade, Slide + Fade, Scale, Zoom, Off. Длительность/интенсивность и прежние motion/reduced switches. Переходы продолжают использовать прежнее bounded damping; значение длительности управляет темпом, это не жёсткая остановка экспоненты в указанную миллисекунду.
- Menu-only particles: Off, Soft Dots, Floating, Sparkles, Dust; amount/speed/size/opacity/direction/color. 64 максимум, 40 в лёгком режиме; zero particle-object allocation при обновлении, примитивы идут в существующий canvas batch. По умолчанию Off. Reduced motion замораживает частицы.
- HSV picker: двумерная saturation/value область, hue, live accent, presets, persistence и клавиши стрелок. Градиенты — два цветных quad в Minecraft, без загрузки текстур каждый кадр. Для читаемости слишком тёмный выбранный цвет осветляется при использовании как foreground accent; сырой цвет сохраняется.
- В HUD/editor подключён тот же custom accent и общий motion-off; existing cards получили деликатный контур. Layout/drag/размеры не переписаны.

### View Model, Swing, Equip

- Независимые Main Hand/Off Hand position/scale/tilt/yaw/pitch с понятными подписями.
- Presets: Default, Compact, Large, Low, High, Custom; применяются к выбранной руке, ручное изменение отмечает Custom.
- Значения: position -0.8..0.8, scale 0.4..1.6, rotation -90..90°. Все проходят validate и сохраняются в существующем Settings.
- `HeldItemRendererMixin`: wrapper точной сигнатуры Yarn 1.21.4 renderFirstPersonItem, scoped MatrixStack push/pop с finally; thread-local static state не используется.
- Swing styles: Vanilla, Smooth, Fast, Wide, Compact, Custom, Off. Smooth/Fast меняют render progress, Wide/Compact/Custom — ordinary swingArm transform; Custom имеет speed/strength/rotation/position/scale influence. Концы progress сохраняют rest pose.
- Equip: Vanilla, Smooth, Fast, Off; отдельное render-only преобразование equipProgress.
- Damage, entity swing timers, packets, attack speed, hit detection и physics не меняются. Fast означает более раннее визуальное движение внутри того же игрового периода, не ускорение ударов.
- Vanilla fallback для пустой руки, карт, арбалета и активного использования предмета; их special animations намеренно не кастомизируются. Это ограничение первой интеграции, не скрытая недоработка UI.
- Live preview: кнопка сужает меню влево и убирает затемняющий фон. Настоящие предметы в мире используют тот же config и Minecraft lighting/depth. Требуется первое лицо и предмет в руке. Off hand/левосторонняя dominant arm и позиция панели нуждаются в проверке на телефоне. Нет отдельно встроенной 3D-сцены/preview FBO.
- «Тест движения» подаёт синтетический progress только в rendering; атак не выполняет. Preview flags не сохраняются и сбрасываются при закрытии/смене вкладки/removed.

## Verified

Логи актуального выполнения находятся в `verification/`:

- `core-tests.log` — старые input/animation/HUD/tool safety/config регрессии.
- `visual-tests.log` — новые config roundtrip, invalid values, main/off presets, progress seams, equip bounds, выбор настроек, закрытие всех стилей, SV picker coordinates, primitive budget.
- `static-checks.log` — существующие model/mobile static checks с обновлённым saturation invariant: luma вместо максимального RGB.
- `shader-webgl.json` — реальные readPixels для 0/50/100/150%, повторная смена uniform, alpha, grayscale/identity, два размера FBO, повторная компиляция GLSL ES. Это не native MG shader conversion.
- `verification/visual/*.png` — Java2D-кадры настоящего общего Menu/Canvas, не Minecraft screenshots. Выполнена ручная проверка компоновки основных новых настроек. FPS на Android не измерялся.

Прежние input-after-close, old-tab zones, drag cancellation/continuation и invalid delta проверки сохранены, не ослаблены. Старый shader-test на неизменный max(RGB) заменён, поскольку он противоречит новой luma-модели. Остальные static проверки сохранены.

## Build / CI — важно

`.github/workflows/build.yml` НЕ ИЗМЕНЁН. Второго workflow нет. Новые core tests вызываются через уже запускаемый MenuChecks.

Существующий workflow ПРЕДПОЧИТАЕТ старый `LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip`, если он лежит в корне репозитория. Чтобы CI не собрал старые исходники:

1. Сделайте резервную копию старого ZIP вне рабочего дерева репозитория.
2. Распакуйте текущую папку LumaVisuals с заменой соответствующих файлов, либо разместите её содержимое в корне существующего проекта.
3. Уберите старый приоритетный ZIP из корня (или замените именно его содержимым текущего проекта).
4. Запустите существующий workflow. Название workflow/artifact останется историческим; версия и JAR name тоже прежние.
5. Проверьте лог компиляции/mixin remapping. Только после успешной сборки переходите к IN-GAME TEST.

## Remaining / IN-GAME test matrix

- [ ] Fabric 1.21.4 + Java 21 build и загрузка мода без Mixin/Shader errors.
- [ ] Чистый профиль Zalith Launcher 2 + MobileGlues: записать телефон, GPU, Android, точную MG версию, ANGLE/native GLES, Fabric/API и остальные моды.
- [ ] Один и тот же кадр при 0/50/100/150%: мир меняется, HUD/menu не меняются; проверить screenshot разницы, daytime/night, вода/прозрачности, gamma/brightness, Ratio on/off.
- [ ] F3+T shader reload, resize/rotate window, выход/вход в мир, переключение saturation on/off; проверить GL logs и отсутствие stale target.
- [ ] Main/off hand, правша/левша, предметы разных типов; пресеты, default identity, rotations, scale, clipping, lighting и near plane.
- [ ] Preview UI: движение ползунков совпадает с миром; никакой атаки/packet при previewSwing; закрытие возвращает управление. Offhand может находиться за левой панелью в отдельных положениях.
- [ ] Swing каждого стиля, Custom 0/min/max, equip независимо, mining/use/map/crossbow fallback; отсутствие изменения частоты настоящих ударов.
- [ ] Порог ToolSafety 1/100/200 и effective 10% cap; warning и stash прежней системы; persistence после restart.
- [ ] Все menu tabs/hover/scroll/drag после смены стиля; быстрое close/reopen, NaN/пауза фрейма, touch controls.
- [ ] Particle Off/максимум, reduced motion, HUD transitions; Android FPS/frametime/GC/память до и после. Zero allocations для всего меню не заявляется: существующий UI создаёт hit/lambda/text объекты; новые частицы не создают объектов на particle/frame.

## Документация и источники

Documentation save: SAVED IN PROJECT ARCHIVE. Этот файл и дополнения README_RU, CHANGELOG_RU, CHECKS, TEST_ON_PHONE, PROJECT_HANDOFF относятся к текущему обновлению. Предыдущие заметки и screenshots сохранены как история, не как доказательство нового игрового запуска.

Проверенные API/reference (2026-09-08):
- https://maven.fabricmc.net/docs/yarn-1.21.4%2Bbuild.8/net/minecraft/client/render/item/HeldItemRenderer.html
- https://maven.fabricmc.net/docs/yarn-1.21.4+build.8/net/minecraft/client/gl/ShaderProgram.html
- https://maven.fabricmc.net/docs/yarn-1.21.4+build.8/com/mojang/blaze3d/platform/GlStateManager.html
- https://github.com/MobileGL-Dev/MobileGlues-release
- https://github.com/MobileGL-Dev/MobileGlues-release/issues/251 (1.21.4 Optifine, не доказательство проблемы Fabric)
- https://github.com/MobileGL-Dev/MobileGlues-release/issues/403 (другая версия игры, только предупреждение о различиях ANGLE/native GLES)

Код/branding/assets других visual mods не копировались.
