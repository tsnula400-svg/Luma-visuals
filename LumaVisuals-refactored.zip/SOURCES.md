# Что изучено перед исправлением

## Основной источник
Предоставленные исходники Luma 0.1.4: HudLayout, HudConfig, HudSettingsPanel, Menu, MinecraftCanvas, LumaHud и preview-тесты. HUD уже подключён через HudLayerRegistrationCallback перед слоем чата. Причина растянутого HUD — фиксированные ширины 140–350 логических единиц и последовательное заполнение ряда с сохранением позиций.

## Версионные источники
- Fabric API 0.119.2 + Minecraft 1.21.4: https://maven.fabricmc.net/docs/fabric-api-0.119.2+1.21.4/net/fabricmc/fabric/api/client/rendering/v1/HudLayerRegistrationCallback.html
- Yarn 1.21.4+build.8 DrawContext: https://maven.fabricmc.net/docs/yarn-1.21.4+build.8/net/minecraft/client/gui/DrawContext.html
- Архитектура HUD 1.21.4: https://github.com/FabricMC/fabric-docs/blob/main/versions/1.21.4/develop/rendering/hud.md
- MobileGlues: https://github.com/MobileGL-Dev/MobileGlues — слой desktop OpenGL поверх OpenGL ES, преобразование GLSL. Совместимость зависит от реализации/драйвера; README не заменяет тест на телефоне.

## Pulse
Прочитан README публичного проекта https://github.com/Lopata12958/PulseVisuals . Он описывает разделение обработчиков событий, визуалов, рендера и конфигурации. Репозиторий сам называет себя вдохновлённым Pulse; не установлено, что это именно проект из референса пользователя. Полный RenderUtils по прямым ссылкам получить не удалось. Код из этого проекта не копировался и его сборка не проверялась.

## Решение
Сохранить уже имеющийся совместимый с выбранным API путь интеграции и менять независимое ядро геометрии/контролов. Размеры — по метрикам текста, три стиля — без новых GPU-проходов. Анимация настроек — экспоненциальное сглаживание по времени кадра, отсечение содержимого; невидимые контролы не участвуют в нажатиях.
