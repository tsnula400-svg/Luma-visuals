# Luma Visuals — Minecraft Java Edition 1.21.4 (Fabric)

Клиентский мод-надстройка (HUD, меню, Custom Skin, Ratio, Saturation, Tool Safety)
для **Minecraft Java Edition 1.21.4** на **Fabric**. Целевая среда запуска —
мобильное устройство: **ZalithLauncher** + транслятор рендера **MobileGlues**
(OpenGL → Vulkan/GLES).

| Параметр | Значение |
| --- | --- |
| Edition | Java Edition (ПК-версия) |
| Minecraft | 1.21.4 |
| Загрузчик мода | Fabric (fabric-loom 1.9.2), требуется Fabric API |
| Java / Gradle | JDK 21 / Gradle 8.12 |
| Версия мода | Alpha 0.1.5 → 0.1.6-audit.1 |
| Хост-лаунчер | ZalithLauncher (Android) |
| Рендер-транслятор | MobileGlues (OpenGL → Vulkan/GLES) |

## Структура

```
CHANGE_MANIFEST_FINAL.json   единый манифест изменений (V2 + Refined + Prism + предыдущий Final)
MOBILE_INPUT_FIX.json        единый манифест фиксов ввода/рендера (MobileFix + InputFix + VerifyFix)
SHA256SUMS.txt               контрольные суммы рабочего дерева
docs/                        сводная документация (RU)
src/                         исходники мода (Fabric, Java 21)
preview/                     офлайн Java2D-превью UI/модели (не скриншоты игры)
audit/                       аудит: shader-webgl.json, TEST_SCOPE.json, логи
tools/                       генераторы ассетов и статические проверки
verification/                логи проверок
.backup/, .backup_manifests/ исходные версии слитых файлов (в git не индексируются)
```

## Документация

- `docs/README_RU.md` — исходный README проекта (RU, история ревизий).
- `docs/CUSTOM_SKIN_FIX_RU.md` — Custom Skin: реализация, история V2/фикса, чек-листы.
- `docs/MOBILE_INPUT_FIX_RU.md` — тач-управление, эмуляция ПК-ввода, Ratio/Saturation, VerifyFix.
- `BUILD_FROM_PHONE.md` — сборка через GitHub Actions с телефона.
- `AUDIT_REPORT_RU.md`, `CHECKS.md`, `TEST_ON_PHONE.md` — аудит и проверки.

## Сборка

```bash
gradle --no-daemon clean build   # JDK 21, Gradle 8.12, доступ к Maven/Fabric/Mojang
# результат: build/libs/luma-visuals-*.jar
```

С телефона — GitHub Actions (`.github/workflows/build.yml`), см. `BUILD_FROM_PHONE.md`.
JAR ставится в `mods/` профиля Minecraft 1.21.4 Fabric вместе с Fabric API;
старую копию мода нужно удалить.

## Статус проверки

Полная Fabric/Gradle-сборка, запуск Minecraft, ZalithLauncher и MobileGlues в среде
подготовки **не выполнялись**. Пройдены только офлайн-проверки: компиляция общего Java-core
(`--release 21`), core/GUI/recording-тесты, статические математические проверки шейдеров.
Проверка на устройстве обязательна.

## Правила репозитория

- Не изменяются: структура конфигов Fabric-мода (`fabric.mod.json`, `luma.mixins.json`),
  JVM-аргументы, схемы раскладки ввода и шейдерные пути MobileGlues.
- Ничего не удаляется безвозвратно: прежние версии лежат в `.backup/` и `.backup_manifests/`.
